#!/usr/bin/env bash
set -euo pipefail
cd /workspace/AI-Optimizer
source artifacts/gpup-delivery-pr-v1/environment.sh
# Each push stays below GitHub's individual pack limit, preserving every commit.
for revision in 8040747 4657c8a HEAD; do
    git -c pack.threads=4 -c pack.window=0 -c pack.compression=1 push origin "${revision}:refs/heads/codex/gpup-delivery2"
done
