import gzip,hashlib,io,json,os,re,subprocess,sys,tarfile,time
from pathlib import Path
ROOT=Path('/workspace/AI-Optimizer');sys.path.insert(0,str(ROOT/'tools'))
from lp_delivery_pr_budget import accounting,admission_open
from lp_delivery_pr_common import BASE,CPU_CAPS,NS,put,ref,load
started=time.monotonic_ns();admission_open()
required=['full-native-v2','isolated-research-v1','clean-portability-v1','clean-process-v1','publish-features-v1','final-review-v1']
for name in required:assert load(BASE/'resources'/f'{name}.settlement.json')['status']=='passed'
receipts=[]
for p in sorted((BASE/'resources').glob('*.settlement.json')):
 s=load(p);r=load(ROOT/s['resource']['path'])
 assert not s['overrun'] and r['guardian_cleanup']['empty'] and r['result']['cleanup']['empty']
 receipts.append(dict(binding=ref(p),settlement=s,supervisor_cleanup_empty=True))
failures=[r for r in receipts if r['settlement']['status']!='passed'];assert len(failures)==1
cpu,gpu=accounting();cpu['cleanup']+=1000*NS
assert all(cpu[k]<=v*NS for k,v in CPU_CAPS.items()) and not gpu
history=load(ROOT/'docs/benchmarks/data/delivery-mixed2-pr-history-v1.json');assert history['preserved_files']==2153
account=ROOT/'docs/benchmarks/data/delivery-mixed2-pr-accounting-v1.json'
put(account,dict(status='closed',cpu_caps_seconds=CPU_CAPS,cpu_ns=cpu,cpu_seconds=sum(cpu.values())/NS,
 gpu_seconds=0,closing_administration_cpu_seconds=1000,closing_scope='Final receipt packaging, documentation, commit, publication, normal merge and guarded cleanup',
 failed_reservations=len(failures),full_failed_charge_cpu_seconds=7200,settlements=receipts,
 supervisor_cleanup_empty=True,historical_transfers=0))
# Preserve the integration sources, failed environment, logs and receipts portably.
files=sorted(p for p in BASE.rglob('*') if p.is_file() and not p.is_symlink() and p.suffix in ('.json','.py','.sh','.log','.md'))
manifest=[dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
archive=ROOT/'docs/benchmarks/data/delivery-mixed2-pr-evidence-v1.tar.gz'
with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tar:
 data=json.dumps(dict(files=manifest),sort_keys=True).encode();info=tarfile.TarInfo('manifest.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
 for p in files:tar.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for item in manifest:
  data=tar.extractfile(item['path']).read();assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
acceptance=ROOT/'docs/benchmarks/data/delivery-mixed2-pr-acceptance-v1.json'
put(acceptance,dict(status='passed',feature_head='2008aa91f7617dcc11479c94f08127191cd67972',base_main='8fe3a20753f641b160e88b2f521d3ebe7c290297',
 original_feature_commits=11,repository_rust_tests=638,isolated_rust_tests=172,total_rust_tests=810,python_tests=781,
 isolated_python_subset=50,oracle_requests=1049,oracle_outputs=5121,
 clean_checkout=dict(initial_tests_run=770,initial_skip_entries=3,followup_process_tests=12,distinct_cases_covered=781,
 shared_dependencies=['immutable Git objects','pinned HiGHS installation','pinned Python/Rust tooling'],copied_project_binaries=False,copied_study_artifacts=False),
 portable_final_confirmation=dict(responses=16384,evidence_files=9543),history=ref(ROOT/'docs/benchmarks/data/delivery-mixed2-pr-history-v1.json'),
 accounting=ref(account),evidence_archive=ref(archive),hosted_initial=load(BASE/'hosted-pr-initial.json'),
 public_default_changed=False,new_scientific_gpu_runs=0,final_hosted_status='Recorded separately in PR #25 and local closing receipts'))
value=load(account);charge=f"{value['cpu_seconds']:.9f}"
p=ROOT/'docs/benchmarks/lp-delivery-mixed2-pr.md';s=p.read_text()+f'''
## Final local acceptance

All required local checks pass. Exactly 2153 historical tracked files remain
byte-exact; all four updated navigation/handoff files preserve their older text.
Public crates, CUDA sources, root dependency locks and hosted workflows match
remote main exactly. The eleven original feature commits retain their ancestry.

The independent allocation is closed at **{charge} / 48000 CPU seconds**,
including the full 7200-second failed environment reservation and a conservative
1000-second closing-administration reserve. GPU usage is zero. All supervised
cleanup is empty. A prematurely queued review was cancelled before reservation;
its record is retained. No closed scientific allocation is reused.

[Acceptance](data/delivery-mixed2-pr-acceptance-v1.json),
[accounting](data/delivery-mixed2-pr-accounting-v1.json),
[historical preservation](data/delivery-mixed2-pr-history-v1.json), and
[portable integration receipts](data/delivery-mixed2-pr-evidence-v1.tar.gz).

[PR #25](https://github.com/liuyumou/OptForge/pull/25) receives this acceptance
commit before normal merge. The final hosted-check and cleanup receipts are
retained under `artifacts/gpup-delivery-pr-v1`; the PR reports hosted status
separately. Verified merged branches and disposable checkouts may be removed;
the unique archival branch and scientific artifacts remain preserved.
''';p.write_text(s)
entry=f'''## DELIVERY/MIXED2 PR acceptance complete (2026-11-14)

The user requests publishing, normally merging and safely cleaning up all
unmerged features. PR #25 integrates eleven original commits from DELIVERY2
through MIXED2-CONFIRM2 with their ancestry and scientific evidence unchanged.
Local acceptance passes 810 Rust / 781 Python tests, the 1049-request / 5121-output
CPU oracle and portable replay, including all 16384 final confirmation responses.
Clean-checkout prerequisite builds resolve all three skipped process-test groups
with 12 passing cases. All 2153 historical files and earlier navigation remain exact.

Hosted Actions reports startup_failure with zero jobs at the original feature
head; final-head status is recorded separately in the PR. Use a normal merge
without changing or bypassing protection. Remove verified merged branches and
clean obsolete worktrees, preserving the unique pre-CI archival branch and all
scientific artifacts. Public defaults, GPUP-8 and GPUP-9 gates stay unchanged.

Separate integration allocation closed at {charge} / 48000 CPU seconds,
zero GPU, including the failed 7200-second environment reservation and 1000
closing-administration seconds. All supervised cleanup is empty; historical
allocations remain closed. No follow-on performance study is released.
Report: [PR acceptance](REPORT_LINK).

'''
for name,link in [('AGENTS.md','docs/benchmarks/lp-delivery-mixed2-pr.md'),('state/active-task.md','../docs/benchmarks/lp-delivery-mixed2-pr.md')]:
 p=ROOT/name;old=p.read_text();pos=old.index('\n')+1;p.write_text(old[:pos]+'\n'+entry.replace('REPORT_LINK',link)+old[pos:])
p=ROOT/'wiki/status.md';s=p.read_text().replace('are being integrated\nthrough the user-requested PR.','have passed acceptance\nfor the user-requested [PR #25](https://github.com/liuyumou/OptForge/pull/25).',1);p.write_text(s)
p=BASE/'pr-body.md';s=p.read_text().replace('Exact historical preservation is checked before the acceptance commit.','All 2,153 historical tracked files are byte-exact; older navigation/handoff text is preserved.').replace('The integration report is `docs/benchmarks/lp-delivery-mixed2-pr.md`.','The integration report is `docs/benchmarks/lp-delivery-mixed2-pr.md`. The failed initial environment reservation retains its full 7,200 CPU-second charge; the separate allocation closes at '+charge+' CPU seconds, including closing administration.');p.write_text(s)
put(BASE/'CLOSED.json',dict(accounting=ref(account),acceptance=ref(acceptance)))
put(BASE/'closing-start.json',dict(started_monotonic_ns=started,prepaid_cpu_seconds=1000))
for name in history['allowed_prefix_only']:
 old=subprocess.check_output(['git','show',history['baseline']+':'+name],cwd=ROOT)
 assert (ROOT/name).read_bytes().endswith(old.split(b'\n',1)[1]),name
for command in [['python3','tools/validate_artifacts.py'],['python3','tools/build_docs.py'],['git','diff','--check']]:subprocess.run(command,cwd=ROOT,check=True)
print(json.dumps(dict(status='ready-to-commit',cpu_seconds=value['cpu_seconds'],gpu_seconds=0,preserved_files=2153,archive_files=len(files)),indent=2),flush=True)
