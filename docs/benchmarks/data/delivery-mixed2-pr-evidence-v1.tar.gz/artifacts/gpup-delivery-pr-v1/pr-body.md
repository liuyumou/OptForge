This PR integrates the eleven unmerged research commits from GPUP-DELIVERY2 through GPUP-MIXED2-CONFIRM2. It preserves their original ancestry, source-bound evidence, failed attempts and historical decisions.

- DELIVERY2 adds checker transport batching and setup overlap; DELIVERY3 separates those controls and records scoped cold improvements; DELIVERY4 adds exact hashing and lifecycle attribution.
- MIXED2 adds the CPU numerical contract, diagnostic product pilot, guarded FP4 tensor increments, changing-model scenario reuse, and complete independent confirmation.
- The final confirmation completes 512 sessions and 16,384 certified solves. Five of eight scoped value comparisons pass; none passes the provisional 1.10x lower bound. Earlier negative and incomplete results remain exact.
- Public solver defaults and original-model certification are unchanged. GPUP-8 remains incomplete and GPUP-9 gated.

Local native acceptance passes 638 Rust / 781 Python tests, dependency policy, committed-record replay, documentation and smoke. All seven isolated research packages pass another 172 Rust tests (810 Rust total), their 50 Python contracts, and the exact CPU oracle's 1,049 requests / 5,121 outputs. Clean-checkout coverage is complete across the initial suite and 12 focused process cases after compiling their three prerequisite executables. Portable replay passes for DELIVERY3/4 and all MIXED2 stages, including all 16,384 final-confirmation responses and 9,543 evidence files. Exact historical preservation is checked before the acceptance commit. No scientific GPU run is part of this integration.

GitHub Actions reports `startup_failure` with **zero jobs launched** for this PR's original feature head ([run](https://github.com/liuyumou/OptForge/actions/runs/43568950701)). Private-repository protection/ruleset inspection returns HTTP 403. Final-head hosted status will be recorded separately; local acceptance is not a hosted pass. Merge uses a normal merge commit without changing or bypassing protection.

The integration report is `docs/benchmarks/lp-delivery-mixed2-pr.md`. Cleanup will remove verified merged branches and clean obsolete worktrees while preserving the unique archival branch and scientific artifacts.
