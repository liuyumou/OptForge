#!/usr/bin/env bash
set -euo pipefail
source /workspace/AI-Optimizer/artifacts/gpup-delivery-pr-v1/environment.sh
cd /tmp/delivery-mixed2-pr-clean-v1
for package in lp-fp4-integrate lp-fp4-accel lp-fp4-checker; do
    cargo build --manifest-path "research/$package/Cargo.toml" --release --locked
done
PYTHONPATH=tests/integration python3 -m unittest -v \
    test_lp_fp4_integrate.Checker \
    test_lp_fp4_accel.RustContracts \
    test_lp_fp4_checker.ProcessGuards
git diff --exit-code
