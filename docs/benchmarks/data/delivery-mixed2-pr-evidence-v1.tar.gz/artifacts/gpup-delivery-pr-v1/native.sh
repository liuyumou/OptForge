#!/usr/bin/env bash
set -euo pipefail
cd /workspace/AI-Optimizer
source artifacts/gpup-delivery-pr-v1/environment.sh
bash tools/check.sh
