#!/usr/bin/env bash
set -euo pipefail
cd /workspace/AI-Optimizer
source artifacts/gpup-delivery-pr-v1/environment.sh
for component in delivery2 delivery3 delivery4 mixed2 mixed2_pilot mixed2_fp4 mixed2_reuse; do
    bash "tools/check_${component}_cpu.sh" artifacts/gpup-delivery-pr-v1/mixed2-oracle.json
done
