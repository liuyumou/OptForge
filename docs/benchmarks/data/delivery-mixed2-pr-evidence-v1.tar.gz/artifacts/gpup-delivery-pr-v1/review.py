import hashlib, json, os, re, subprocess
from pathlib import Path
ROOT=Path('/workspace/AI-Optimizer'); BASE=ROOT/'artifacts/gpup-delivery-pr-v1'
baseline=json.loads((BASE/'baseline-tree.json').read_text())
allowed={'AGENTS.md','CHANGELOG.md','state/active-task.md','wiki/status.md'}
rows=[]
for item in baseline['files']:
    meta,name=item.split('\t',1); mode,kind,expected=meta.split(); p=ROOT/name
    assert kind=='blob'
    if name in allowed:
        old=subprocess.check_output(['git','show',baseline['head']+':'+name],cwd=ROOT)
        assert p.read_bytes().endswith(old.split(b'\n',1)[1]),name
        continue
    size=len(os.readlink(p).encode()) if mode=='120000' else p.stat().st_size
    h=hashlib.sha1(b'blob '+str(size).encode()+b'\0')
    if mode=='120000': h.update(os.readlink(p).encode())
    else:
        with p.open('rb') as f:
            while chunk:=f.read(1<<20):h.update(chunk)
    assert h.hexdigest()==expected,name
    rows.append(dict(path=name,git_blob=expected))
assert subprocess.run(['git','diff','--quiet',baseline['base'],baseline['head'],'--','crates','cuda','Cargo.toml','Cargo.lock','.github'],cwd=ROOT).returncode==0
for key in ['full-native-v2','isolated-research-v1','clean-portability-v1','clean-process-v1','publish-features-v1']:
    s=json.loads((BASE/'resources'/f'{key}.settlement.json').read_text())
    assert s['status']=='passed' and not s['overrun'],key
    r=json.loads((ROOT/s['resource']['path']).read_text())
    assert r['guardian_cleanup']['empty'] and r['result']['cleanup']['empty'],key
out=ROOT/'docs/benchmarks/data/delivery-mixed2-pr-history-v1.json'
out.write_text(json.dumps(dict(baseline=baseline['head'],base_main=baseline['base'],preserved=rows,
    preserved_files=len(rows),allowed_prefix_only=sorted(allowed),older_navigation_exact=True,
    public_crates_cuda_dependencies_workflows_exact=True),indent=2,sort_keys=True)+'\n')
print('Historical preservation passed:',len(rows),'files; old navigation exact',flush=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['python3','tools/validate_artifacts.py'],cwd=ROOT,check=True)
subprocess.run(['python3','tools/build_docs.py'],cwd=ROOT,check=True)
