#!/usr/bin/env bash
set -euo pipefail
cd /workspace/AI-Optimizer
source artifacts/gpup-delivery-pr-v1/environment.sh
git clone --local --shared --branch codex/gpup-delivery2 /workspace/AI-Optimizer /tmp/delivery-mixed2-pr-clean-v1
cd /tmp/delivery-mixed2-pr-clean-v1
mkdir -p target/native
ln -s /workspace/AI-Optimizer/target/native/highs-1.11.0 target/native/highs-1.11.0
cargo build --workspace --locked
python3 tools/lp_generate.py --extension
python3 -m unittest discover -s tests/integration -p 'test_*.py'
python3 tools/verify_committed_record.py
python3 tools/validate_artifacts.py
python3 tools/lp_delivery3_diagnose.py --output artifacts/delivery3-diagnosis-pr.json
cmp artifacts/delivery3-diagnosis-pr.json docs/benchmarks/data/delivery3-diagnosis-v1.json
python3 tools/lp_delivery4_replay.py
python3 tools/lp_mixed2_cost.py --verify
python3 tools/lp_mixed2_pilot_analysis.py verify
python3 tools/lp_mixed2_fp4_analysis.py verify
python3 tools/lp_mixed2_reuse_analysis.py verify
python3 tools/lp_mixed2_confirm_analysis.py verify
python3 tools/lp_mixed2_confirm2_analysis.py verify
python3 tools/lp_mixed2_confirm2_evidence.py portable
git diff --exit-code
