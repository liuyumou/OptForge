#!/usr/bin/env bash
set -euo pipefail
cd /workspace/AI-Optimizer
source artifacts/gpup-delivery-pr-v1/environment.sh
python3 artifacts/gpup-delivery-pr-v1/review.py
