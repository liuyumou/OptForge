import hashlib,json,shutil,subprocess,sys,tarfile
from pathlib import Path
ROOT=Path('/workspace/AI-Optimizer'); BASE=ROOT/'artifacts/gpup-delivery-pr-v1'
def cmd(*args,cwd=ROOT):return subprocess.check_output(args,cwd=cwd,text=True).strip()
assert not cmd('git','status','--porcelain'), 'dirty source checkout'
raw=json.loads(cmd('gh','api','repos/liuyumou/OptForge/pulls/'+sys.argv[1]))
assert raw['merged'] is True,raw['state']
merged=dict(url=raw['html_url'],mergeCommit=dict(oid=raw['merge_commit_sha']))
subprocess.run(['git','fetch','origin','main:main'],cwd=ROOT,check=True)
head=cmd('git','rev-parse','HEAD');main=cmd('git','rev-parse','main')
assert main==merged['mergeCommit']['oid']
subprocess.run(['git','merge-base','--is-ancestor',head,'main'],cwd=ROOT,check=True)
subprocess.run(['git','switch','main'],cwd=ROOT,check=True)
removed=[]
for branch in ('codex/gpup-delivery2','codex/gpup-8','codex/gpup-baseline','codex/gpup-resident2'):
    tip=cmd('git','rev-parse','refs/heads/'+branch)
    subprocess.run(['git','merge-base','--is-ancestor',tip,'main'],cwd=ROOT,check=True)
    remote=cmd('git','ls-remote','--heads','origin','refs/heads/'+branch)
    if remote:
        remote_tip=remote.split()[0]
        subprocess.run(['git','merge-base','--is-ancestor',remote_tip,'main'],cwd=ROOT,check=True)
        subprocess.run(['git','push','--force-with-lease=refs/heads/'+branch+':'+remote_tip,'origin',':refs/heads/'+branch],cwd=ROOT,check=True)
    subprocess.run(['git','branch','-d',branch],cwd=ROOT,check=True)
    removed.append(dict(branch=branch,tip=tip,remote_deleted=bool(remote)))
old=Path('/tmp/gpup-adaptive-cost-baseline')
assert not cmd('git','status','--porcelain','--untracked-files=all',cwd=old)
old_head=cmd('git','rev-parse','HEAD',cwd=old)
subprocess.run(['git','merge-base','--is-ancestor',old_head,'main'],cwd=ROOT,check=True)
ignored=cmd('git','ls-files','--others','--ignored','--exclude-standard',cwd=old).splitlines()
archive=BASE/'obsolete-worktree-ignored-v1.tar.gz'
with tarfile.open(archive,'w:gz',dereference=False) as t:
    for name in ignored:t.add(old/name,arcname=name,recursive=False)
subprocess.run(['git','worktree','remove',str(old)],cwd=ROOT,check=True)
clean=Path('/tmp/delivery-mixed2-pr-clean-v1')
assert not cmd('git','status','--porcelain','--untracked-files=all',cwd=clean)
clean_head=cmd('git','rev-parse','HEAD',cwd=clean)
subprocess.run(['git','merge-base','--is-ancestor',clean_head,'main'],cwd=ROOT,check=True)
shutil.rmtree(clean)
assert not cmd('git','status','--porcelain')
assert cmd('git','rev-parse','main')==cmd('git','rev-parse','origin/main')
value=dict(status='passed',pull_request=merged['url'],merge_commit=main,removed_branches=removed,
    removed_worktrees=[dict(path=str(old),head=old_head),dict(path=str(clean),head=clean_head)],
    ignored_worktree_archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    preserved_archival_branch=cmd('git','rev-parse','codex/gpup-baseline-before-ci-manifest'),
    scientific_artifacts_preserved=True,worktree_clean=True)
(BASE/'cleanup.json').write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
print(json.dumps(value,indent=2),flush=True)
