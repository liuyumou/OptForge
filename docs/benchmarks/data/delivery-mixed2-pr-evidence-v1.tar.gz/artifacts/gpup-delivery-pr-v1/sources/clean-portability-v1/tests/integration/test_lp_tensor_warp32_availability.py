"""Reject source drift while retaining the approved availability-test bridge."""
import copy
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'tools'))
from lp_protocol import ROOT, read_json
from lp_tensor_warp32_availability_bridge import (
    SOURCE, BRIDGE, MARKER, verify_test_only_change, verify_source_mapping, verify_cpu_sources,
)


class AvailabilitySourceBridgeTests(unittest.TestCase):
    def setUp(self):
        from lp_tensor_warp32_common import numeric_sources
        cpu = read_json(ROOT / 'docs/benchmarks/data/tensor-warp32/cpu-admission-v1.json')
        from lp_resident2_test_support import historical_registration
        self.enterContext(historical_registration())
        current = numeric_sources()
        # The later expanded cohort added four independent translation units.
        # Explicitly assert that delta, then exercise the frozen warp32 roster.
        additions = {'cuda/lp_pdhg_tensor_expanded/' + name for name in [
            'expanded_guard.cu', 'expanded_primitives.cu',
            'expanded_products.cu', 'expanded_reconstruct.cu']}
        additions |= {'cuda/lp_pdhg_resident2/lp_pdhg_resident2.cu', 'crates/optimizer-lp-cuda/src/resident2.rs'}
        self.assertEqual(set(current), set(cpu['numerical_sources']) | additions)
        self.assertTrue(additions.isdisjoint(cpu['numerical_sources']))
        historical = {name: current[name] for name in cpu['numerical_sources']}
        self.enterContext(patch('lp_tensor_warp32_common.numeric_sources', return_value=historical))

    def test_actual_admission_and_prior_driver_production_bytes_are_preserved(self):
        cpu = read_json(ROOT / 'docs/benchmarks/data/tensor-warp32/cpu-admission-v1.json')
        verify_cpu_sources(cpu)
        row = next(r for r in read_json(BRIDGE)['files'] if r['path'] == SOURCE)
        verify_test_only_change((ROOT / row['frozen_path']).read_bytes(), (ROOT / SOURCE).read_bytes())

    def test_production_mutation_and_missing_or_duplicate_boundaries_refuse(self):
        original = b'production' + MARKER + b'old tests}'
        verify_test_only_change(original, b'production' + MARKER + b'new tests}')
        for changed in [b'changed' + MARKER + b'new tests}', b'production', original + MARKER]:
            with self.assertRaises(ValueError):
                verify_test_only_change(original, changed)

    def test_changed_admission_hash_or_roster_refuses(self):
        cpu = read_json(ROOT / 'docs/benchmarks/data/tensor-warp32/cpu-admission-v1.json')
        bad = copy.deepcopy(cpu)
        bad['numerical_sources'][SOURCE] = '0' * 64
        with self.assertRaises(ValueError):
            verify_cpu_sources(bad)
        bad = copy.deepcopy(cpu)
        bad['numerical_sources'].pop(SOURCE)
        with self.assertRaises(ValueError):
            verify_cpu_sources(bad)

    def test_non_test_source_drift_refuses(self):
        with patch('lp_tensor_warp32_availability_bridge.file_hash', return_value='changed'):
            with self.assertRaises(ValueError):
                verify_source_mapping({'cuda/lp_pdhg_tuned/lp_pdhg_tuned.cu': 'original'})


if __name__ == '__main__':
    unittest.main()
