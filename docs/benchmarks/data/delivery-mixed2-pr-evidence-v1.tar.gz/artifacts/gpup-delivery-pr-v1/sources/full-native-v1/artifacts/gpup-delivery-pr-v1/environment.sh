#!/usr/bin/env bash
set -euo pipefail
export PATH="/tmp/ai-optimizer-venv/bin:/tmp/ai-optimizer-cargo/bin:$PATH"
export RUSTUP_HOME=/tmp/ai-optimizer-rustup
export COPT_HOME=/root/copt80
export COPT_LICENSE_DIR=/root/copt80
export CUDA_VISIBLE_DEVICES=""
