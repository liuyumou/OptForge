# Known Failures and Limitations

## GPUP-8 closure and hosted startup remain separate (2026-11-15)

[ADR-0076](../docs/decisions/ADR-0076-gpup8-disposition.md) closes GPUP-8
negatively without changing its incomplete scientific result. The replacement
complete-cost gate remains unpassed; prepared and within-lane gains are not
cold FP4 superiority. All earlier failures below retain their historical scope.

CI-STARTUP: main run 43677094346 at e0d9e8ad3ebea268299150b47df758002ce695a8
reports startup_failure with zero jobs and zero GitHub Actions check runs, while
Actions is enabled. No runner evidence identifies a build/test or account cause.
Owner/service diagnostics and a normal hosted pass are required; local acceptance
is separate. See [current observation](../docs/benchmarks/lp-gpup8-disposition.md#hosted-ci-observation).

## MIXED2 pilot scope and retained development failures (2026-11-12)

The new pilot separates diagnostic admission from the provisional 1.10x adoption
target. Instrumentation perturbs timing, product probes are not a solver, and
useful mixed windows, work amplification and recovery costs remain unmeasured.
No adoption or public preset follows from eight descriptive blocks.

Three development reservations are preserved in full: Rust buffer type inference
1440 CPU seconds, an expected pre-CUDA model refusal misclassified by the sanitizer
report parser 600 CPU / 150 GPU seconds, and a reporting syntax error 360 CPU
seconds. Corrected versions pass; no scientific cell was retried. [Report](../docs/benchmarks/lp-mixed2-pilot.md).

## MIXED2 device work deferred by complete-cost admission (2026-11-12)

The [CPU admission report](../docs/benchmarks/lp-mixed2.md) rejects cold arithmetic
optimization: even eliminating every GPU event yields only 1.010266x dense gain.
Prepared 1.151630x is a hypothetical whole-event 2x scenario, not a measured
mixed result. Matrix-only attribution, work amplification and added representation,
guard, transfer, correction/fallback/checking costs remain unknown. There is no
GPU implementation or new mixed certificate. A separate attribution/admission
slice is required; opaque CPU checkpoints and local bounds do not establish
executor completeness, accumulated-state error or convergence. No default change.

## FP4 prototype has no CPU-qualified persistent lane (2026-11-11)

The [frozen prototype admission](../docs/benchmarks/lp-fp4-proto-gpup-fp4-proto.md)
refuses all twelve cells before any 200-update observation: nine cumulative
error-guard refusals and three incompatible checkpoint error budgets. Low
component counts show actual quantization error; eight-component cases also show
bound inflation from losing primal/dual cancellation. No device, actual-MMA,
sanitizer or profile stage ran. Full prototype acceptance remains incomplete.

Frozen v1 remains exact. The separate v2 correction sums rounding and encoding
errors so cancellation cannot hide the checkpoint's representation remainder;
three primitive regressions pass. No corrected scientific attempt has run and
this fix does not qualify a lane. Future enclosure changes require a versioned
proof/contract and new admission; original-model checks and the 1e-9 final
certificate stay unchanged. The failed CPU qualification and software launcher
retain their full charges. GPUP-FP4-RECOVERY-SPEC is the next planning task.

## RESIDENT2 synchronization savings do not establish a latency win (2026-11-11)

The [completed resident study](../docs/benchmarks/lp-resident2-gpup-resident2.md)
reduces waits but increases transfer bytes; the cold geomean is 1.027370x and
four certified medians regress. Keep the native control. Prepared batches are
throughput observations, not single-solve wins. All twelve mixed-model normal
limits deliver actual vectors but retain the unchanged variable-3 infinite-bound
refusal. No artificial finite bound or certificate relaxation is introduced.
The initial overflow stimulus and stale test executable failures are preserved;
the corrected acceptance and four sanitizer gates pass with all charges retained.


## Completed baseline retains native and quality failures (2026-11-10)

The [completed native-return report](../docs/benchmarks/lp-external-baseline-native-return.md) has no unexecuted
screening cells. Completion means all planned attempts are accounted for, not
that every solver succeeds. CuOpt has 90/96 native-return passes and 24/96
strict certificates; the native termination counts are {'IterationLimit': 45, 'Optimal': 42, 'NumericalError': 3, 'TimeLimit': 3, 'unavailable': 3}.
Error-free time/iteration limits are passes under the user's rule but remain
limits. A return may pass natively while outer transport times out; those rows
have no successful complete-delivery time or fabricated certificate.

The large mixed model has no strict certificate from any configuration. Project
native limit endpoints remain available, but nonzero CLI exit prevents
export through the retained adapter. Native project assessment and independent
vendor checks lack a finite bound for an unbounded variable; this does not prove
the model unbounded. See the completed report for exact source-bound differences.

Raw numerical differences, all prior failures and the unresolved presolve-only
maximization dual mapping remain. That mapping may involve the adapter, so it is
not attributed to a cuOpt design defect. Reused small-model v2 and new v5 transport
are different cohorts; their cross-cohort paired ratios are withheld. The new
report supersedes the incomplete coverage status below without changing it.

## External baseline admission and coverage (2026-11-10)

The [implemented baseline](../docs/benchmarks/lp-external-baseline-gpup-baseline.md)
admits six configurations and certifies 108 of 123 executed screening cells.
cuOpt double violates original componentwise feasibility on admission; mixed
reaches its iteration limit with violations; single misses the strict gap on a
tiny equality; concurrent has an unresolved presolve-only maximization dual sign.
The installed CUDA stack executes cuOpt. These are quality/mapping limits, not
an installation failure or a general commercial-solver ranking.

Fifteen executed screening cells are uncertified: three each for HiGHS native
failure/missing-candidate handling on scaling, COPT default scaling gap, COPT GPU
scheduling gap, HiGHS large-irregular numerical failure, and COPT default
large-irregular native limit without a witness. Raw records remain available.
Ninety-six planned cells are cuOpt-admission-blocked; 21 further cells cannot fit
the CPU screening phase. No unsupported timing or speedup is substituted.

The new harness initially hit a mistaken artifact size limit, then expensive
schema validation and unbuffered certificate output. Separate v3/v4 corrections
preserve the cancelled job, all sixteen timeout trials and full charges. Passed
admissions/small-model blocks and numerical refusals are reused. Complete delivery
still includes substantial host/evidence cost; native-only times are diagnostic.
See the [follow-up decisions](../docs/plans/gpu-lp-precision-roadmap.md#baseline-follow-up-decisions).

## Current precision-performance limitation (2026-11-10)

GPUP-8 remains incomplete after proof/device acceptance and a large BF16 profile
timeout. Retained small profiles identify expanded reconstruction and state-update
cost as the dominant bottleneck; no supported low-precision recipe or certified
latency gain follows. See the [system diagnosis](../docs/benchmarks/lp-system-diagnosis-2026-11-10.md)
and [current roadmap](../docs/plans/gpu-lp-precision-roadmap.md#current-plan-2026-11-10).
cuOpt is installed and executes, but its four baseline configurations remain
unadmitted for the reasons above. Gurobi is unavailable. Historical failures and scientific execution stops below
remain preserved; the new plan does not reopen them.

## GPUP-8 corrected proof and device acceptance pass; profile timeout (2026-10-24)

Final delivery passes 173 documentation pages/internal links, immutable evidence
checks and staged diff hygiene. Four exact hash-bound EOF blank-line exceptions
preserve historical/generated bytes; all other whitespace checks pass.
Cumulative CPU is 59603.097503214 / 77640 seconds; this recovery charges
8034.404049688. Timing and restricted-margin funds remain unused.
All coordinator/guardian cleanup receipts are empty. Final accounting:
docs/benchmarks/data/tensor-expanded/recovery-final-accounting-v1.json.
Final journal: artifacts/gpup-tensor-expanded-v1/recovery-hygiene-v1/cpu-journal-final-v21.json.

The corrected 7376-case proof, CPU/model/native gates and all six device jobs pass.
All twelve fixed-work/replay pairs are accounted for; twenty changed endpoints
independently verify once. Six small-model profiles complete. The first large-model
BF16 profile times out at its unchanged 18-second deadline without an endpoint.
Nine profiles and sixty timings remain unexecuted. Preserve the full 3200 CPU-second
profile failure charge and every source, image, receipt and historical charge.
No completed check/profile is rerun; no numerical or latency criterion changes.
GPU charge is 178.049776450 seconds; GPUP-8 1410.959187474/3000 and campaign
22770.545043263/25202.574545061. The 17438-event ledger
preserves the exact 17412-event prefix. Timing funds remain unused.
Report: docs/benchmarks/lp-tensor-expanded-recovery-gpup8.md.
Scientific stages are closed. GPUP-8 remains incomplete; GPUP-9 stays gated.

## GPUP-8 expanded-window proof stops on noncanonical fixture (2026-10-24)

Final CPU-only delivery passes source/evidence preservation, documentation/internal links,
syntax and diff checks. Cumulative CPU is 51568.693453526 / 77640;
continuation charge 5666.151624356 seconds. Reporting retains
761.762326424 seconds. All failure/delivery cleanup is empty.
Final journal: artifacts/gpup-tensor-expanded-v1/cpu-journal-final-v4.json.
Final report: docs/benchmarks/lp-tensor-expanded-final-gpup8.md.
Exact accounting: docs/benchmarks/data/tensor-expanded/final-cpu-accounting-v1.json.

ADR-0046 and the 24000-CPU-second / 1760-existing-GPU-second amendment are accepted.
Twelve authority/evidence and sixteen new CPU prototype checks pass. The new
scalar host harness compiles with UBSan, then rejects input 19: the generator
changes a short subnormal significand's exponent to -63 without normalization.
No scalar result was independently compared before the return-code refusal; no
arithmetic defect is inferred. Preserve the original corpus, sources and failure.

The full 5600 CPU-second proof reservation remains charged. Scientific stages
are closed; no correction/retry, implicit transfer or later scientific stage.
Implementation/native/device/profile/timing allocations remain unused. No old
passed check or profile is rerun and no GPU work or commit occurs. GPUP-8 stays
incomplete, GPUP-9 gated; cross-window persistence remains future work.
The exact 17412-event GPU ledger is unchanged. Both proof cleanup receipts are
empty. CPU-only delivery uses the separate reporting allocation.
Report: docs/benchmarks/lp-tensor-expanded-gpup8.md. Diagnosis:
docs/benchmarks/data/tensor-expanded/proof-fixture-diagnosis-v1.json.
Failed journal: artifacts/gpup-tensor-expanded-v1/cpu-journal-proof-stop-v2.json.

## GPUP-8 receipt correction passes; gain forecast refuses (2026-10-24)

Seventeen focused correction checks and exact source/provenance admission pass.
Sixteen separately stored corrected trial views bind the existing independent
verification receipts; every original trial retains its null link and exact hash.
No passed check, profile or retained numerical verification is rerun. The original
strict reader accepts the corrected views. All sixteen profiles and useful
integer/floating families satisfy the unchanged profile/forecast inputs.

The unchanged gain forecast now runs and refuses all six candidates. The best
small-model forecast is 0.642764297 s against the 0.415902600 s threshold; the best
large-model forecast is 8.977063370 s against 5.697919800 s. This is a forecast
refusal, not a measured primary timing comparison or numerical failure. No
resource-fit gate or timing worker follows. Preserve the corrected views,
original records, sources, reports, full historical charges and new forecast.

The forecast stage retains its full 400 CPU-second failure charge. The separate
6400-second timing reservation stays unused. The CPU-only scientific report
passes with original completion calculations and receipt reuse. Scientific stages
are closed; no automatic retry or implicit transfer follows. GPUP-8 remains
incomplete and GPUP-9 gated. There is no new GPU work: warp32 remains
369.700946478 / 1640, GPUP-8 1232.909411024 / 3000, and campaign
22592.495266813 / 25202.574545061. The exact 17412-event ledger remains unchanged.
Final CPU accounting is 45902.541829170 / 53640; this receipt recovery charges
843.323873964 CPU seconds entirely from unused funds. Reporting retains
315.762945624 CPU seconds. Delivery passes 168 documentation pages/internal
links, exact preservation of 637 original artifacts and sixteen corrected views,
source metadata and diff hygiene. All workload and guardian cleanup is empty.
Final closed journal: artifacts/gpup-tensor-warp32-v1/cpu-journal-receipt-final-v31.json.
Exact accounting: docs/benchmarks/data/tensor-warp32/receipt-final-cpu-accounting-v1.json. Cleanup is empty.
No host/container/supervisor change, bootstrap rerun, commit, publication or merge.
Report: docs/benchmarks/lp-tensor-warp32-receipt-recovery-gpup8.md.
Refusal: docs/benchmarks/data/tensor-warp32/receipt-forecast-refusal-v1.json.

## GPUP-8 approved receipt-link recovery (2026-10-24)

The user authorizes correcting receipt links in separate versioned records and
continuing GPUP-8 using unused funds. Preserve original trials/receipts, all
sources, failures and charges, and the exact 17412-event GPU prefix. Rerun no
passed checks or profiles. All scientific completion criteria remain unchanged.

Reallocated existing CPU headrooms: implementation 240, forecast 400, timings
6400, reporting 600 and restricted termination margin 400 seconds. No additional
CPU/GPU budget; CPU ceiling 53640 and warp32 GPU cap 1640 (330/320/990) remain.
Active journal: artifacts/gpup-tensor-warp32-v1/cpu-journal-receipt-recovery-v29.json.
Write artifact-only correction/reader adapters, run focused correction acceptance,
then the interrupted forecast and conditional timing sequence. No automatic
retry, host/container/supervisor change, bootstrap rerun or GPUP-9. Likely writes:
new correction manifests, journal/receipts/report and state documentation.
Accepted plan: docs/plans/lp-tensor-warp32-receipt-recovery.md.

## GPUP-8 funded continuation stops at profile receipt binding (2026-10-24)

The approved 10400 CPU-second addition and 850 GPU-second reallocation are
recorded. Fourteen new adapter checks and exact source/provenance admission pass.
Initcheck and synccheck pass; full device acceptance reuses ordinary/project tests,
all twelve fixed-work/replay pairs and 24 verifications, memcheck and racecheck.
All sixteen profile workers complete with independent verification receipts.
The frozen writer captures artifact references before creating verification
receipts, leaving every trial's verification reference null. The strict forecast
reader refuses these links. No forecast or timing runs, and no numerical or gain
failure is inferred. Preserve every source, trial, receipt and the traceback.

The profile stage retains its full 2400 CPU-second failure charge. The separate
6400-second timing reservation remains unused. Scientific stages are closed;
there is no automatic repair/retry or implicit transfer. Four new post-stop
reader checks and the CPU-only report pass using sixteen profile, 24 acceptance
and 24 historical CPU verification receipts, with no numerical verification rerun.
Completion criteria are unchanged. GPUP-8 remains incomplete and GPUP-9 gated.

This continuation charges 113.279588268 GPU seconds; combined warp32 is
369.700946478 / 1640 (acceptance 261.200177856 / 330,
profiles 108.500768622 / 320, timings 0 / 990).
GPUP-8 is 1232.909411024 / 3000; campaign is
22592.495266813 / 25202.574545061. The exact 17412-event ledger
preserves the 17376-event prefix. Workload and guardian cleanup are empty.
Final CPU accounting is 45059.217955206 / 53640; this continuation charges
2664.409180444 CPU seconds. Reporting retains
466.729267256 seconds, unavailable for automatic retries. Delivery passes
166 documentation pages/internal links, exact source/evidence preservation and
diff hygiene. Every workload and guardian cleanup receipt is empty. Final closed
journal: artifacts/gpup-tensor-warp32-v1/cpu-journal-funded-final-v28.json.
Exact accounting: docs/benchmarks/data/tensor-warp32/funded-final-cpu-accounting-v1.json. No host/container
or supervisor change, bootstrap rerun, commit, publication or merge occurs.
Report: docs/benchmarks/lp-tensor-warp32-funded-gpup8.md.
Failure receipt: docs/benchmarks/data/tensor-warp32/funded-profile-refusal-v1.json.

## GPUP-8 approved fully funded continuation (2026-10-24)

The user approves 10400 additional CPU seconds and 850 GPU seconds reallocated
from GPUP-8's existing allowance. CPU ceiling 53640; warp32 GPU cap 1640,
including all prior charges, with acceptance/profiles/timings caps 330/320/990.
Prospective CPU allocations are implementation 200, sanitizers 1000, profiles
2400, timings 6400, reporting 600 and restricted termination margin 400.
Active journal: artifacts/gpup-tensor-warp32-v1/cpu-journal-funded-continuation-v26.json.

Reuse all passed checks and exact verification receipts. Artifact-only adapters
must pass focused acceptance and exact source/provenance admission first. Run
only initcheck and synccheck, then the frozen sixteen profiles and conditional
sixty timings, in separate CPU reservations. Original scientific criteria,
source/image identities and every historical charge remain unchanged. Preserve
the exact 17376-event GPU prefix. No automatic retry, implicit transfer, host or
container change, supervisor change or bootstrap rerun. GPUP-9 remains gated.
Likely writes: artifact adapters/journal/receipts, new budget policy, reports and
task documentation. Accepted plan: docs/plans/lp-tensor-warp32-funded-continuation.md.

## GPUP-8 deadline recovery result (2026-10-24)

Final result: all twelve fixed-work/replay pairs and all 24 independent endpoint
verifications pass; ordinary/project-unit tests and software/inventory acceptance
were reused, not rerun. The resumed project and memcheck/racecheck pass. Initcheck
is refused before reservation because its required 36 GPU seconds exceed the
remaining 33.578641790 acceptance seconds. Synccheck and all 76 study
cells remain unexecuted. The full 3600-worker-CPU-second failure charge is retained.

The separately funded CPU report passes with no verification errors, and 164
documentation pages/internal links plus diff hygiene pass. All cleanup is empty.
This recovery adds 160.386137810 GPU seconds; combined warp32 consumption is
256.421358210 / 790, entirely within the 290-second acceptance cap.
GPUP-8 total is 1119.629822756 / 3000; campaign total is
22479.215678545 / 25202.574545061. The exact 17376-event ledger
preserves both the 17370-event and 17366-event prefixes. Final CPU is
42394.808774762 / 43240; this recovery charges 3663.609175120 CPU seconds.
Reporting retains 213.895961888 CPU seconds; worker headroom is zero.
Exact accounting: docs/benchmarks/data/tensor-warp32/deadline-final-cpu-accounting-v1.json.
Final failed/closed journal:
artifacts/gpup-tensor-warp32-v1/cpu-journal-deadline-final-v25.json.
All historical sources, frozen requests, failures, images and charges remain.
No numerical/latency relaxation, automatic retry, implicit phase transfer or
local commit occurs. GPUP-8 remains incomplete; GPUP-9 stays gated.

The approved deadline continuation has finished its bounded attempt. See
 docs/benchmarks/lp-tensor-warp32-deadline-recovery-gpup8.md and the separate
machine report for exact status. All earlier failures/charges and passed checks
remain preserved; no full software or inventory rerun occurs. Scientific work
stops at the recorded failure/refusal or completed sequence; all original
completion criteria and the combined 790-GPU-second cap remain unchanged.
Final accounting follows supervisor finalization. GPUP-9 remains gated.

## GPUP-8 deadline relaxation selected; CPU funding pending (2026-10-24)

The user authorizes reasonable operational deadline relaxation. Selected:
180 seconds for the remaining project acceptance actions, 60 seconds for final
reporting. Numerical and completion criteria and the 790-second GPU cap remain
unchanged. Passed checks and all failed charges are retained. Worker CPU funds
are exhausted. The concrete proposal requests 3600 new CPU seconds plus unused
implementation/native/reporting reallocation; prospective ceiling 43240. Funding
is unaccepted, so no scientific execution resumes. See
 docs/plans/lp-tensor-warp32-deadline-recovery.md.

## GPUP-8 inventory complete; project acceptance timed out (2026-10-24)

Final metadata delivery validates the inventory/composite, all fifteen completed
verification bindings, exact ledger/prefix and 162 documentation pages/internal
links plus diff hygiene. It does not replace either failed gate or complete the
sixteenth endpoint verification. Final CPU is 38710.817591066 / 39640;
this adapter recovery charges 4097.609224304 CPU seconds with all historical
charges preserved. Reporting retains 23.730196880 CPU seconds,
unavailable for automatic retries. Exact accounting:
 docs/benchmarks/data/tensor-warp32/native-final-cpu-accounting-v5.json.
Final failed/closed journal:
artifacts/gpup-tensor-warp32-v1/cpu-journal-inventory-device-final-v20.json.
All cleanup is empty. The exact 17370-event ledger and historical 17366-event
prefix verify unchanged after delivery. No local commit occurs.

The approved adapter correction and 36-worker-CPU-second transfer pass six new
focused checks and exact provenance admission. All four compile-only device
suites and explicit composite acceptance pass without rerunning passed software
checks. The frozen source/archive and all prior failed reservations remain exact.

All 66 ordinary device tests pass. The project unit suite passes 280 product
pairs, five controller comparisons and 32 warp32 bit/refusal witnesses, then
hits its unchanged 60-second deadline during fixed-work/replay acceptance.
Seven of twelve required pairs have complete host-verification receipts; an
eighth pair is retained with its replay verification incomplete. Sixteen
endpoints and fifteen completed verification receipts remain. No sanitizer,
profile or timing follows. The separate CPU-only final-report attempt also
reaches its deadline; no complete final verification report is claimed. Preserve
both failed sources/receipts and full charges: workers 3964, reporting 64 CPU
seconds. All workload/guardian cleanup is empty.

New GPU charge 96.035220400 / 790 seconds; GPUP-8 959.243684946 / 3000;
campaign 22318.829540735 / 25202.574545061. The 17370-event ledger SHA-256 is
2dac176a925a0bba6096eea8f57ed694465c0199625d120eeb32d468310dc4e4,
preserving the exact 17366-event prefix. CPU at worker stop is
38616.699832818 / 39640; at reporting stop 38684.699832818. Final metadata
accounting follows. Scientific stages are closed; no automatic retry, implicit
transfer or criterion relaxation. GPUP-8 remains incomplete; GPUP-9 stays gated.
Report: docs/benchmarks/lp-tensor-warp32-inventory-device-gpup8.md.

## GPUP-8 inventory admission stops before compilation (2026-10-24)

Final CPU-only delivery passes exact failure/source/receipt/budget checks,
161 documentation pages/internal links and diff hygiene. No passed software
check is rerun. Final cumulative CPU is 34613.208366762 / 39640;
this continuation charges 104.152044872 CPU seconds, retaining all
prior charges. Reporting retains 117.847955128 CPU seconds;
unused funds do not authorize an automatic retry. Final failed/closed journal:
artifacts/gpup-tensor-warp32-v1/cpu-journal-inventory-admission-final-v16.json.
Exact accounting: docs/benchmarks/data/tensor-warp32/native-final-cpu-accounting-v4.json.
Workload/guardian cleanup and diagnostic/delivery cleanup are empty. Fresh hashing
confirms the unchanged exact 17366-event GPU ledger. No commit occurred.

The approved 2500 CPU-second increase and proposed reallocation are recorded:
cumulative ceiling 39640, continuation allocation 9840, unchanged 790 GPU cap
and completion criteria. All covered sources match the passed 1137-file archive;
only 15 exact metadata paths differ. Eleven new adapter checks pass, then
provenance admission fails on the adapter's assumption that extracted Cargo
packages contain .cargo-checksum.json. Charge the full 64 CPU seconds. This is
an adapter assumption error, not an observed dependency or numerical failure.
Post-stop CPU-only diagnosis verifies all 26 retained locked crate archives and
every extracted member; all 26 lack that metadata file. A separate correction
draft is unexecuted. No inventory command, composite acceptance, freeze or GPU
work occurs, and no passed software check is rerun. Both cleanup receipts are
empty; the exact 17366-event GPU ledger is unchanged. CPU at setup stop is
34581.056321890 / 39640; reporting charges follow separately.

Scientific stages are closed; no automatic retry or implicit transfer. GPUP-8
remains incomplete; GPUP-9 stays gated. Preserve all failed sources and charges.
Report: docs/benchmarks/lp-tensor-warp32-inventory-admission-gpup8.md. The separate
unaccepted recovery proposes a 36-worker-CPU-second transfer, no new CPU budget,
one corrected admission and the unchanged inventory/device/completion sequence.
See docs/plans/lp-tensor-warp32-inventory-admission-recovery.md.

## GPUP-8 availability fixed; inventory deadline stops recovery (2026-10-24)

The user-approved 1240 additional CPU seconds are recorded: cumulative ceiling
37140, continuation allocation 7340, unchanged 790-GPU-second cap. The CUDA
availability tests now distinguish initialization from version-query failures;
the actual availability test and four new mocked Rust cases pass. Eight source-
bridge checks pass. Production driver/numerical bytes and historical CPU evidence
remain exact through the separate test-only source bridge.

Every tools/check.sh command passes on source
267c5b7488482ea9005f359e367dcff2b97f363fe2e9ffd7b6008db5cb897138:
Clippy, Rust/native, 424 Python tests, dependencies, replay, 157 documentation
pages and CPU smoke. The complete source tree is archived. The supervisor then
reaches its 298-second work deadline before compile-only device inventory
completes. The combined native/resource gate is refused; its full 1200 CPU
seconds remain charged. No complete inventory, freeze, device acceptance,
sanitizer, profile or timing follows. No numerical failure is inferred.

Both workload and guardian cleanup are empty. The exact 17366-event GPU ledger
remains 9142829b3be8afdb1865425c83ca9122371284ca0e16f7bc8b18d303a5894426;
GPUP-8 remains 863.208464546 / 3000 GPU seconds. CPU at the native stop is
34458.336534342 / 37140; final CPU-only delivery is separately charged.
Scientific stages are closed. No automatic retry, implicit transfer, bootstrap
rerun, host/container change, supervisor change, numerical/latency relaxation,
commit or GPUP-9. Preserve every prior failure/source/image/journal/report.
See docs/benchmarks/lp-tensor-warp32-availability-recovery-gpup8.md and
 docs/benchmarks/data/tensor-warp32/native-refusal-v3.json.

Final CPU-only delivery passes exact failure/source-archive/ledger checks, 158
documentation pages/internal links, CPU smoke and diff hygiene. Cumulative CPU is
34492.792106322 / 37140; this availability recovery charges
1263.732468604 CPU seconds, retaining all prior charges.
Reporting retains 25.307512328 CPU seconds, unavailable for an
automatic retry. Final failed/closed journal:
artifacts/gpup-tensor-warp32-v1/cpu-journal-availability-final-v11.json.
Exact accounting: docs/benchmarks/data/tensor-warp32/native-final-cpu-accounting-v3.json.
Native and delivery cleanup are empty. No new GPU work or commit occurred.


## GPUP-8 corrected native gate stops at driver availability (2026-10-24)

The approved 1200-native/40-reporting transfer is recorded and the one new
native gate runs once. Clippy passes, but the existing CUDA driver-availability
test rejects an error from driver_version while the native wrapper hides all
CUDA devices. Source inspection identifies an unhandled Driver error path;
the exact driver call/status is absent from the failure log. No numerical
failure is inferred. The full 1200 CPU seconds remain charged. No complete
native/Python integration gate or compile-only inventory passes, and no GPU
work, frozen study, bootstrap rerun, host access or container change occurs.
Cleanup is verified empty. Scientific stages are closed under ADR-0045; there
is no automatic retry or implicit transfer. GPUP-8 remains incomplete and
GPUP-9 stays gated. The exact 17366-event GPU ledger is unchanged.

At the native stop cumulative CPU accounting is 33196.332668818 / 35900.
Final CPU-only delivery passes exact failure-source/receipt checks, 156
documentation pages/internal links, repository CPU smoke and diff hygiene.
These checks do not replace the failed full native gate. Cumulative CPU is
33229.059637718 / 35900; continuation charge is
3474.353823460 CPU seconds. Reporting retains
19.763084308 CPU seconds, unavailable for automatic retries.
The final failed/closed journal is cpu-journal-native-stop-final-v8.json;
exact accounting is docs/benchmarks/data/tensor-warp32/native-final-cpu-accounting-v2.json.
Both cleanup receipts are empty, and fresh hashing verifies the unchanged exact
17366-event GPU ledger. No new GPU work, host/container change or commit occurs.
 Failure receipt:
`docs/benchmarks/data/tensor-warp32/native-refusal-v2.json`. Preserve all prior
native failures, sources, journals, images, endpoints and reports.

## GPUP-8 approved native recovery (2026-10-24)

The user explicitly approves one new full native gate after the retained
one-line fixture correction, transferring 1200 unspent worker CPU seconds to
native acceptance and 40 to reporting. All prior failures and charges remain.
Active journal: artifacts/gpup-tensor-warp32-v1/cpu-journal-native-recovery-v6.json.
Continuation allocations including charges are implementation 258, proofs 800,
native 2400, workers 2052, reporting 190 and margin 400 CPU seconds, total 6100.
Cumulative CPU accounting after bounded authorization bookkeeping is
31996.332668818 / 35900. Run the approved 1200-CPU-second native gate once.

If every native check and compile-only inventory passes, freeze all behavior
and run the existing conditional device sequence under the 2052-worker-CPU-
second envelope and 790-GPU-second cap (290 acceptance, 200 profiles, 300
timings). Select this active journal at runtime before worker admission; keep
the verification-cache helper source unchanged. Preserve the exact 17366-event
GPU prefix and every historical source, image, journal and report. Per-job
CPU/GPU admission and the frozen forecast/resource-fit rules can refuse early.
No host access, bootstrap rerun, supervisor change, unrelated-process signals,
container configuration change, numerical/latency relaxation or automatic retry.
GPUP-8 remains incomplete until every unchanged completion criterion passes;
GPUP-9 stays gated. The accepted plan is
[the native recovery](../docs/plans/lp-tensor-warp32-native-recovery.md).

## GPUP-8 warp32 native-gate final handoff (2026-10-24)

The corrected image passes 88-register/zero-spill admission and 592 independent
bit/refusal cases. All 48 eight-model CPU cells are retained, 24 endpoints
independently verify, and all twelve required dense configurations admit useful
400-update trajectories. Ten launcher/harness tests pass. The full native gate
fails Clippy on a redundant i32 cast in the new device fixture: charge all 1200
CPU seconds and retain the original source/failure. The one-line fix preserves
all admitted numerical-source hashes. Targeted format, 155 docs pages, CPU smoke
and diff checks pass; a full native pass remains unclaimed. No new GPU work,
resource-bootstrap rerun, host access, container change or commit occurs.

Final CPU accounting is 31980.332668818 / 35900; continuation charge is
2225.626854560. Reporting retains 12.490053208 CPU seconds. Exact receipt:
docs/benchmarks/data/tensor-warp32/native-final-cpu-accounting-v1.json. Final
failed/closed journal: artifacts/gpup-tensor-warp32-v1/cpu-journal-native-handoff-v5.json.
All cleanup is verified empty. The exact 17366-event GPU ledger stays unchanged.

The proposed native recovery transfers 1200 native and 40 reporting CPU seconds
from workers, leaving 2052 worker CPU seconds, under the unchanged 6100 total,
35900 ceiling, 790 GPU cap and completion criteria. It is unaccepted; no repeated
native gate or GPU reservation is authorized. GPUP-8 stays incomplete and GPUP-9
stays gated. See docs/plans/lp-tensor-warp32-native-recovery.md.

## GPUP-8 warp32 native fixture Clippy failure

The corrected image passes 88-register/zero-spill admission, 592 independent
bit/refusal cases and the complete eight-model CPU cohort. Native acceptance
then fails because its new device fixture casts i32 to i32. Charge all 1200
native CPU seconds, preserve the failure and old fixture, and stop. Cleanup is
verified empty; no device work ran. The one-line cast removal leaves every
admitted numerical-source hash unchanged. The
[native recovery proposal](../docs/plans/lp-tensor-warp32-native-recovery.md)
requests stage transfers within existing ceilings; it is unaccepted and no
automatic retry, hardware gate or criterion relaxation follows.

## GPUP-8 final warp32-launch handoff (2026-10-24)

GPUP-8 remains incomplete. The isolated correction is written but uncompiled.
Compiler launch fails because replaced PATH hides Python: charge 108 CPU seconds.
CPU-only delivery passes four mocked launch tests, exact historical preservation
and 153 docs pages; smoke then cannot find rustc: charge its full 100 CPU seconds.
No smoke retry, completed final gate or numerical acceptance is claimed. All
project cleanup is verified empty; no new GPU execution, bootstrap rerun, host
access, container configuration change or commit occurs. Final CPU accounting is
30008.459145450 / 35900. New continuation CPU charge is 253.753331192 seconds.
The final failed/closed accounting journal is
artifacts/gpup-tensor-warp32-v1/cpu-journal-accounting-v3.json; exact receipt is
docs/benchmarks/data/tensor-warp32/final-cpu-accounting.json. Reporting retains
42 CPU seconds, unavailable for automatic retries. The separate recovery plan
proposes one corrected compiler invocation and transfer of 108 unspent worker
CPU seconds to implementation, with all charges, criteria and the 790-GPU-second
cap preserved. It is unaccepted; scientific stages remain closed.

## GPUP-8 warp32 compiler entry loses Python

The accepted ADR-0045 source/config setup and historical preservation checks
pass, but its compiler-launch command replaces PATH and hides Python. env
returns 127 before formatting or compilation. The supervisor charges the full
108 CPU seconds and verifies empty cleanup. No new image, CPU numerical cohort,
native/device gate, bootstrap rerun or GPU work ran. The correction is written
but uncompiled/unaccepted. Preserve the failed journal and partial sources.
The [recovery proposal](../docs/plans/lp-tensor-warp32-launch-recovery.md) prepares
an entry that preserves PATH and uses sys.executable, with mocked regressions.
One corrected launch and a 108-worker-CPU-second transfer require explicit
approval under ADR-0045's stop rule. Mandatory CPU-only delivery remains funded;
no automatic retry or numerical/latency relaxation follows.

## GPUP-8 device reference reduction order mismatch

The repaired supervisor passes 26 checks and full pre-device native acceptance
passes 405 Python tests plus Rust/native/dependencies, replay, 149 docs pages and
smoke. All 66 ordinary GPU tests and 280 product pairs pass. The first INT8
controller comparison fails after 64 logical updates / two audits: the new
device audit's serial sparse sum differs from the host oracle's warp32 order.
Preserve the frozen source/image and [failure report](../docs/benchmarks/lp-tensor-cost-device-gpup8.md).
No actual-model fixed-work/replay pair, sanitizer, profile or primary timing runs.
GPUP-8 remains incomplete; no numerical/latency relaxation or automatic retry.
Charge 38.094432271 GPU seconds and all conservative CPU failure reservations.
CPU-only reporting stays separate from the frozen execution cohort. A quoted
`SKIP` check in the failed Python traceback initially caused a posthoc reader
false positive; retain that failed phase and full 250 CPU seconds, and match
runtime skip lines explicitly. No extra resources or host access follow.

The [proposed ADR-0045](../docs/decisions/ADR-0045-warp32-tensor-reference-recovery.md)
plans one isolated warp32-order correction and a separately frozen continuation,
using 6100 existing unspent CPU seconds and at most 790 GPU seconds. It retains
all completion criteria and adds aggregate resource admission. It is not
accepted or implemented and does not lift the retained device stop.

## GPUP-8 native completion transport and registration scope

The first full native command passes Rust/native and dependency checks, then
finishes 401 Python tests with one failure: the prior source-scope reader lacks
this continuation's separate registration bridge. Docs/smoke remain unrun.
Independently, its final coordinator observation exceeds the guardian's 65536-byte
socket read and is truncated. The resource receipt is missing, so charge all
2200 native CPU seconds and stop the failed journal. The printed
`refused_before_launch` is misleading here: the command ran. All three recorded
supervisor/entry identities exited; no GPU work or reservation occurred.

The [refusal](../docs/benchmarks/data/tensor-cost/native-transport-refusal.json)
retains 25507.557917574 CPU seconds. A durable bounded result, small hash-bound
completion packet, four regressions and historical source-chain repair are
prepared but unrun. The [reallocation proposal](../docs/plans/lp-tensor-cost-transport-recovery.md)
needs explicit acceptance before resource tests or another native gate. It adds
no resources and changes no numerical/latency criterion. GPUP-8 is incomplete.

## GPUP-8 development integration watchdog stop

The corrected bootstrap and all 22 supervisor checks pass. The authorized
workspace-read retry also succeeds. A subsequent development integration run was
assigned too short a budget: its 160-CPU-second reservation supplies a 38-second
work deadline after margins. The guardian stopped it and verified empty cleanup;
the full reservation is charged. No native acceptance result or GPU work follows.
The source-bound [refusal receipt](../docs/benchmarks/data/tensor-cost/development-watchdog-refusal.json)
retains the failed journal and cumulative 23020.213097770 CPU seconds. GPUP-8
remains incomplete. Recovery needs explicit approval under ADR-0044's stop rule;
it would preserve all charges and use existing stage caps, without bootstrap or
study retries. Earlier bootstrap/inspection failures remain preserved separately.

## GPUP-8 supervisor bootstrap Python portability refusal

The user accepted revised ADR-0044 and its CPU allocation. The first real
bootstrap fails because this Python 3.11.14 build does not expose os.pidfd_open.
No workload command is released, and no numerical/device work runs. All bootstrap
processes exited. The original source, unsettled journal and captured error are
preserved in the [separate refusal](../docs/benchmarks/data/tensor-cost/supervisor-bootstrap-refusal.json).
Charge the full 100 CPU seconds and keep the task journal failed. A portable
Linux wrapper and pre-fork capability check now have four mocked regressions;
these do not prove runtime admission. Explicit authorization is required for a
corrected bootstrap, under ADR-0044's no-automatic-retry rule. GPUP-8 is incomplete.

## GPUP-8 proposed cooperative in-container admission

The user requests an [ADR-0044 amendment](../docs/decisions/ADR-0044-tensor-cost-continuation.md)
with a practical process supervisor and CPU budget. It explicitly replaces hard
cgroup containment with cooperative launch/slot ownership, inherited four-CPU
affinity, a guardian/subreaper, sampled RSS and four-times-wall CPU charging.
Memory peaks between samples, task-wide swap prevention and simultaneous loss
of both supervisors remain limitations; none may be reported as cgroup compliance.
The proposed 16000 CPU seconds need 14300 additional seconds and explicit transfer
of the remaining 1700; the proposed cumulative ceiling is 35900. This is a draft,
not approved execution or a passed bootstrap. Numerical and latency gates are
unchanged. The exact prior ADR and planning sources have separate archived copies.

## GPUP-8 constrained Kubernetes executor

The user confirms Kubernetes and prohibits leaving this container. The
[revised plan](../docs/plans/lp-tensor-kubernetes-constraint.md) withdraws host
provisioning from the task; read-only cgroup controls cannot meet ADR-0044.
No equivalent in-container containment implementation is demonstrated. The
250-second CPU admission and 100-second reporting stages are fully charged;
their renewal requires an explicit allocation, not implicit borrowing from the
1700 seconds remaining in other stages. Additional GPU time does not fix this.
The user's 3600-GPU-second offer remains unreserved. GPUP-8 stays incomplete.

## GPUP-8 ADR-0044 resource admission refused

The user accepted ADR-0044 and its bounded continuation. The
[actual preflight](../docs/benchmarks/lp-tensor-cost-gpup8.md) refuses: read-only
cgroup mount, no delegated task subtree, shared 90-core/200-GiB limits and no
reachable host manager. Per-tree monitoring cannot satisfy the accepted aggregate
containment requirement. Seven simulated refusal regressions pass; a real
coordinator, preparation, full native acceptance and GPU reservations remain
unstarted. Preserve the historical overlap and exact 17362-event GPU ledger.
Conservative new CPU charge is 350 seconds for admission/refusal delivery;
GPUP-8 remains incomplete pending host-provided delegated task containment.

## GPUP-8 latency and CPU admission follow-up

The [CPU-only diagnosis](../docs/benchmarks/lp-tensor-latency-diagnosis.md)
separates shared preparation/policy costs from Tensor arithmetic. Existing forced
tuned profiles use a research wrapper and cannot supply phase attribution for
unchanged tuned timings. Per-tree CPU monitoring allowed overlapping four-worker
admission and four-job compilation. Current cgroup controls are read-only and
do not enforce task limits; delegated task containment is required by
[ADR-0044](../docs/decisions/ADR-0044-tensor-cost-continuation.md).
The proposal was subsequently accepted; the actual admission refusal is recorded
above. Historical overlap stays uncertified; new source-bound resource admission
must pass before any new device reservation.

## GPUP-8 residual continuation lacks a certified latency gain

Initial CPU admission and native compilation overlapped with four workers/jobs
configured for each. Aggregate four-job concurrency and overlap RSS are not
certified. Preserve this resource limitation separately from numerical/device
correctness and the latency failure; see the separate CPU concurrency receipt.


Accepted [ADR-0043](../docs/decisions/ADR-0043-tensor-residual-continuation.md)
repairs the ADR-0042 vector-range refusal with explicit FP64 residuals. All thirty
Tensor timings certify with useful work on both dense models and no promotion;
all sixty timings certify overall. Nevertheless every adjusted speedup interval
is below one. INT8 medians are 0.614776/10.390881 s versus tuned FP64
0.462114/6.331022 s. The [separate report](../docs/benchmarks/lp-tensor-residual-gpup8.md)
retains all 75 cells, twelve full profiles and 120 verified LP records. GPUP-8
remains incomplete on latency; the frozen continuation is exhausted. Preserve
all historical evidence and exact ledger prefixes. No retry, additional study,
preset or GPUP-9 allowance follows from unused resources.

## GPUP-8 component range admission remains incomplete

Accepted [ADR-0042](../docs/decisions/ADR-0042-hybrid-tensor-components.md)
implements bounded 56-bit block components. The two dense models select 96.97%
of coefficients, but both lose nonzero dual values below their block integer
unit before a useful 32-update window. Uniform sticky native replay restores
progress while consuming charged work. The first 1024-row witness is
2.0816681711721685e-17 at update four; the 65536-row case refuses at update three.
CPU cohorts, witnesses and compiler receipts are retained separately. The first
BF16 compile used 136 registers; bounded loop scheduling reaches 48 with zero
spills. The first GPU gate caught a repeated vector-fragment input; its source/image and
2.105369475-second charge remain. Corrected loaders pass 260 product pairs, five
controller pairs and all four sanitizers. The frozen study retains 27 executions
and 48 CPU refusals; all 20 admitted FP64 timings certify but no Tensor solve or
gain qualifies. All four profiles finish; the matched endpoints remain unclosed.
All 128 retained LP records freshly verify. Total task charge is 236.856927634 s;
17200 ledger events retain the exact prior prefix. The bounded evaluation is
finished and GPUP-8 remains incomplete.
GPUP-8 cannot complete from native promotion, operator-only evidence or no gain.

## Quantization PR review preserves measured cohorts

The [separate PR review](../docs/benchmarks/lp-quant-pr-review.md) repairs mutable
prepared operators, partial promotion on an invalid tile ID, unchecked window
counters, noncanonical JSON shapes, inconsistent promotion histories and physical
accounting in host verification. Interrupted workers cannot provide profile
comparisons, and review outputs cannot overwrite historical artifacts or aliases.
The rebuilt executable has no new device acceptance or measured performance
claim. Both original reports, admission receipts, workers, images, source cohorts
and the exact 17132-event ledger remain unchanged. Live-source GPU admission
continues to reject the rebuilt executable against the historical admission;
the PR reader verifies retained evidence separately, on CPU.

## Resident execution recovers FP64 coverage, not useful matrix quantization

[GPUP-7R](../docs/benchmarks/lp-quant-resident-gpup7r.md) completes accepted
ADR-0041 inside existing ceilings. All 36 admitted fresh timings certify, retaining
36/108 planned coverage and 78 CPU-refused quantized timing/profile cells. All
three native profiles finish 2000 logical updates; 21 operator endpoints verify.
The 72-cell CPU cohort admits no useful low-precision audit window for any of
the six candidates on eight models. Scaling-256 retains a bridge numerical
refusal; every historical GPUP-7 refusal/outcome remains separate.

Resident FP64 updates, compact segments and two-level device guards eliminate
the old matched path's timeout behavior on this cohort, but unchanged tuned FP64
remains faster on all nontrivial models. Irregular-32768 medians are 4.799867 s
resident matched versus 2.564014 s tuned. Conservative steps, audits/assessment
and preparation remain material. Quantized synthetic products pass but recorded
trajectory products mostly fail 1e-7 bounds; even unguarded quantized products
are slower in these single diagnostics. No LP FP16/FP8 benefit or preset follows.

Full native/device/replay/four sanitizer gates pass. Preserve the invalid command
preflight (no GPU reservation), source bridge broadening sanitizer scope before
execution, all CPU cohorts, both frozen source cohorts, workers/images/requests
and every historical artifact. Final CPU verification accepts 313 LP endpoints
plus 21 operator endpoints. Task charge is 245.686586823 GPU seconds; cumulative
21359.585855789 / 25202.574545061. The 17132-event ledger SHA-256 is
930de6771ab9bfbcb855bd05a07a58f6700aa1ade36bca09346790a94e7ff035, preserving
the exact 17036-event prefix below. GPUP-8 needs its own conditional contract;
unused allowance reserves nothing. Tensor Cores, vector quantization, combined
methods, sessions and supported presets remain gated.

## Bounded matrix quantization promotes before useful low-precision work

[GPUP-7](../docs/benchmarks/lp-quantization-gpup7.md) completes the accepted
ADR-0040 matrix-only subset. All 104 attempts remain, 34 study endpoints verify
and 33/96 timings certify. Each of the six candidates and matched FP64 certifies
only small-4 at the initial host point with zero iterations/kernel launches.
Tuned FP64 certifies 12/12; 70 new-path timing/profile timeouts remain. No sparse
FP16/FP8 solve benefit or supported preset is established.

In CPU admission, irregular-2048 and irregular-32768 perform only the initial
zero-dual product in low precision before whole-operator sticky promotion; all
six candidates have the same one-transition disposition. Selective promotion
exceeds the 25% coefficient cap. Accurate products, summary scans, transfers and
host updates remain charged. Seven scaling-256 configurations, including native
matched FP64, refuse the original-unit error budget. Admission preserves 49
work-limit and seven numerical-failure endpoints; this is not a convergence claim.

All eight GPU diagnostic cells are censored: seven time out and unchanged tuned
FP64 certifies after 1400 rather than 2000 updates. No full-horizon comparison
follows. CPU-only reader review explicitly rejects incomplete horizons and CPU
fallback as a GPU timing; actual results/charges remain identical. Both reports,
exact source bridges, frozen workers/images and all failed attempts remain.
Fresh CPU verification accepts all 182 retained endpoints across the study,
acceptance/replay and two CPU admission cohorts, adding zero GPU work.

The initial CPU RSS sampler missed worker-thread subprocesses; retain its raw
receipt and the conservative four-process bound below 8 GiB. The corrected
monitor visits every thread child list and checks source stability. Full native,
66 ordinary/three new device tests, 384 product vectors, six CPU/device controller
comparisons, 18 fixed-work endpoints/18 bitwise replays and four sanitizers pass.
Task charge is 1382.959456122 GPU seconds; cumulative 21113.899268966 /
25202.574545061. The 17036-event ledger SHA-256 is
861c90d8d82a20ff9655173742db37a5047d315e8cc4c983e0d6b2e6fa09bb97,
retaining the exact 16816-event prefix and all earlier history. GPUP-8 needs its
own conditional numerical/hardware/resource contract; unused headroom reserves
nothing. Vector quantization, combined methods, sessions and presets remain gated.

## Assessment scheduling saves checks without recovering precision coverage

[GPUP-ASSESS](../docs/benchmarks/lp-assessment-scheduling-gpup-assess.md) completes
ADR-0039 fixed_200/bounded_800 scheduling on tuned FP64 and existing accumulation
FP32. All 60 attempts remain; 57 endpoints verify and 24/48 timings certify.
All six 2000-update profile pairs match bitwise. Fewer assessments yield a scoped
1.0272x FP64 irregular-32768 paired speedup (three repetitions; 95% interval
1.0190–1.0342), with unchanged coverage and no supported preset. Small-case
intervals cross one; diagnostics do not establish general benefit.

FP32 retains its numerical failures after 47000/40464/20400 physical updates on
irregular-2048/irregular-32768/mixed-65536. Bounded scheduling cuts assessments
235→62/203→53/102→28 but cannot restore original-model feasibility/certification.
Three fixed-FP64 mixed timings time out without endpoints; bounded FP64 reaches
50000 updates with no certificate. A completed diagnostic or work limit is not a
successful certified timing. No delayed/missed success occurs in retained traces;
synthetic cases still demonstrate transient success loss and a 600-update delay.

CPU-only final review repairs float-value replay equality, which can miss opposite
signed-zero bits, and excludes unverified/partial profile files from comparisons.
All twelve retained replays already agree bitwise; the rebuilt host verifier
accepts all 57 available endpoints. Exact source bridges and the unchanged
original report/worker/image/ledger identities remain; no GPU job is repeated.
Full pinned-native, 66 ordinary/three new device tests, six fixed-work policy
pairs/twelve replays and all four scoped sanitizers pass.

PR review reproduces and repairs checkpoint transfer into a fresh same-engine
session with replenished resources, inconsistent failure metadata, oversized
controller counters and partial profiles borrowing a longer policy horizon.
CPU regressions and exact source receipts retain each repair; all retained
profiles are complete and the study's numerical results/charges are unchanged.
The revised executable has no new GPU acceptance or measured timing claim.
Final reader review also intercepts and repairs a default output collision with
the earlier CPU-review report; both historical report paths and aliases are now
protected. A separate final source bridge preserves both PR review cohorts.

Task charge is 523.674592721 GPU seconds (413.636131592 timing, 32.633232920
profiles, 77.405228209 acceptance), within 2300 and every phase cap. Cumulative
consumption is 19730.939812844 / 21602.574545061 seconds. The 16816-event ledger
SHA-256 dd5d7281a152d8fb56df373d913ac2dc7077aac9cf6ba2eb5f6e7781493ea52c preserves
the exact 16684-event prefix and all earlier history. GPUP-7 needs its own accepted
quantization/error-budget and resource contract. No new allowance or reservation;
full expansion state, selective precision, sessions and presets remain gated.

## Bounded refinement loses coverage and guards dominate costs

Prepublication review repairs stale logical checkpoint metadata, missing-candidate
trace acceptance, a skipped final assessment after refresh/promotion offsets,
and incomplete instruction parsing. Regressions reproduce the original faults;
all 39 available refinement endpoints pass the rebuilt host verifier. Exact
before/after source hashes preserve the original measured workers, report and
all GPU receipts; no GPU execution is repeated and the negative result below
is unchanged. See the report's review section and source bridge.

[GPUP-REFINE](../docs/benchmarks/lp-refinement-gpup-refine.md) completes the
accepted ADR-0037 native-FP64-outer correction/anchored-product slice. It retains
108 attempts, independently verifies 48 endpoints and certifies 30/96 timings.
Tuned FP64 certifies 21/24; each refinement mode certifies only 3/24, on small-4
at the initial host check with zero inner/device work. Its scoped latency gain
is not evidence for correction LPs, FP32 products or anchors. No preset is selected.

Scaling-256 promotes FP32 once, charges failures/refreshes and ultimately refuses
`operator_error_budget` in native arithmetic; all nine endpoints fail original
feasibility. Fifty-four other refinement timings and six larger profiles time out
without complete endpoints. Original-model certification remains authoritative.
The 2048-row fixed-work profiles spend about 2.34–2.39 seconds in product guards
and about 13 ms in kernels/readback; additional host FP64 updates and error mapping
dominate remaining cost. These results reject the evaluated implementation as a
general latency improvement, without ruling out separately contracted alternatives.

The first acceptance job was blocked before launch because an unselected device
returned N/A telemetry. ADR-0038 binds both strict management queries to the selected
UUID; v2 retains the same numerical source/ELFs/images and selected 5090. The v1
refusal/0.125948387-second charge and all unexecuted v1 cells remain. The final CPU
report initially read a compact wrapper as a record; its failure log and exactly
bound reader/test correction remain, with no execution repeated. All v2 native,
66 ordinary device tests, 1920 refinement product checks, nine replay pairs and
four scoped sanitizers pass. Independent Fraction checks validate 93 endpoint
merit enclosures/39 contractions. A subnormal rounded-step counterexample is
retained and refused by the actual-step guard.

Task charge is 1541.719136512 GPU seconds; cumulative consumption is
19207.265220123 / 21602.574545061 seconds. The 16684-event ledger SHA-256 is
e83d07792fb0775fc26d8d2cca8a2411f59fcbc94f742cafd8f6b844ffb60535, preserving the
16452-event prefix and every earlier prefix/phase ceiling. No new allowance or
next-task reservation follows. GPUP-ASSESS is next; full expansion masters,
selective precision, assessment scheduling, sessions and supported presets remain
gated. Historical unrelated racecheck/session/mixed-model gaps remain open.

## Full expansion state: first construction fails; compact scalar alternative fits

[GPUP-STATE](../docs/benchmarks/lp-expansion-state-gpup-state.md) closes its bounded
investigation under ADR-0036 with an admission refusal. The 320-bit dot and
unprojected update constructions fit at 62/76 registers with no spills. However,
the required full-range scalar FMA cannot inherit the sparse row's exponent window.
Its first 3200-bit exact-bin implementation uses 255 registers, 152 stack bytes,
296 spill-store bytes and 152 spill-load bytes in both 48/64-bit variants, exceeding
the accepted 128-register/zero-spill gate. LOCAL=0 alone does not mean no spills.

PR 19 review resolves this particular scalar obstacle with a full-range compact
FMA: both formats compile to 40 registers and zero stack/spills under the same
options and gate. The rounding proof and 5900 additional independent cases per
construction pass, including host UBSan and the original FMA cases. The original
refusal remains exact, but no longer supports stopping on scalar resource grounds.
The compact scalar passes 6170 device cases, fresh-process repeatability, four
scoped sanitizers and 36 independently verified primitive timing attempts on
RTX PRO 6000 Blackwell. Division/root/transcendental implementations, the complete
controller and original-model error budgets remain open. No solver performance or
whole-controller resource result follows from the scalar kernel. Dependent
patterns cost about 7928–11724 cycles/FMA; no FP64 comparator was executed.
The first 5090 attempt was blocked before child launch by external activity;
41 remaining v1 cells stay unexecuted. The user authorized the idle PRO 6000
cohort. Memcheck's raw zero-error stdout and original missing-receipt classification
are retained; a bound CPU-only correction accepts that receipt without reexecution.

The review also repairs skipped uniform-predicated instructions and missing
frozen transcendental execution in the archive verifier. The complete file
inventory is now required. Corruption and isolated-archive regressions pass;
the original archive re-verifies unchanged. New evidence and the preliminary
freeze with missing verifier-only imports remain under
artifacts/gpup-state-pr-review-20261013.

The independent CPU fixture validates 192 integer cases, 270 FMA cases, 64 update
graphs and 48 log/exp cases. Compilation and instruction inspection run no GPU
job. Neither complete expansion controller, snapshots/replay nor the proposed
96-timing/12-profile study is implemented/admitted. No solver residual/timing or preset claim follows; the separate scalar
device checks above do not qualify the full primitive family. This rejects the tested full-bin
construction, not all guard/sticky or explicit-scratch alternatives; those need
their own bounded contracts and accounting. No automatic hybrid fallback occurs.

The original CPU/compile-only result charged zero GPU seconds. Its device extension
charges 30.114068273 seconds, including blocked admission; cumulative consumption
is 17665.546083611 / 21602.574545061 seconds. The 16452-event ledger SHA-256 is
24949150272600fe58364f25ebbf7bf892f7454da342edc268d50684568c5f18, preserving the
16366-event prefix 4d083cdb06b4baa38452bb331541fa8874614aeb037f34e40001ce9692ede26b.
The log/exp oracle initially used insufficient absolute squaring resolution and
was corrected to 2048 bits; failed generation/parser receipts are preserved too.
At that dated handoff GPUP-REFINE still needed its own accepted SPEC-0021 subset
and allocation; its completed bounded evaluation is recorded above.

## Bounded exact executor: range refusals and no fresh-solve speedup

[GPUP-EXEC](../docs/benchmarks/lp-exact-executor-gpup-exec.md) passes its bounded
exact-dot arithmetic and device gates under ADR-0035. All 27 cached/uncached
study pairs match bitwise. The 128-bit product-exponent window refuses scheduling,
scaling and mixed models; no term is dropped and no automatic fallback occurs.
The remaining five timing models certify in both exact modes, but the measured
executor provides no fresh-solve latency win over tuned FP64. Lower kernel-host
cost than generic precision FP64 at scale is outweighed by preparation, allocation
and complete witness/checking costs. FP64 state/control and prior scaled-matrix
error remain; full expansion state remains gated, and the subsequent bounded
refinement evaluation is recorded above.

Fourteen first-repetition FP64 controls exited during discovery because the frozen
directory omitted schedule_eval.cubin. The unchanged dependency was restored from
the accepted source archive, with an explicit repair receipt. Those identities
remain failed, charged and unretried; paired timing cells therefore have at most
two control repetitions. The final freeze helper requires the image before any
reservation, and source-only regressions cover this failure and child exit status.
All six mixed-model control timings time out. All 108 attempts remain, 94 endpoints
independently verify and 58/96 timings certify. Scope: development data on one
device; no supported preset, cross-device equivalence or historical gap closure.

CPU review also moved malformed budget rejection ahead of private-ledger loading
so source-only tests work without campaign artifacts. The accepted path still
requires the entire historical prefix. Independent acceptance reporting now binds
every request identity and re-verifies all six project endpoints and six replays
with the frozen executable; measured workers and evidence are unchanged.

PR 18 self-review binds acceptance commands, archived executables/images and the
selected device, and requires all 66 regular tests (the previous prose said 58).
Recovered complete endpoints are independently verified while their interrupted
status and conservative crash charges remain. Six CPU regressions cover these
checks and keep the declared source-correction scope limited to tooling. The
measured runtime, raw results and GPU ledger are unchanged.

## CPU expansion range and preparation defects corrected in PR 17

The original candidate and rational oracle both accepted an overflowing 2-norm as
finite. Review added independent rounding-boundary enumeration and repaired range
checks, canonical underflowed zero, like-signed FMA zeros and nonfinite projection
refusals. Strict codec-field/range checks reject malformed inputs. Preparation now
admits resources before traversal and binds shape and transpose-map metadata into
generations; apply validation requires a current vector epoch. Thirteen regressions
retain the counterexamples. The original frozen fixture remains byte-identical;
review logs and original receipts are in artifacts/pr17-review-20261013.

## CPU expansion reference is accepted; full expansion solver state remains unimplemented

GPUP-REP accepts the bounded CPU subset of SPEC-0020 under ADR-0034. The exact
input codec, correctly rounded binary64 reference and separate 64-significand-bit
expansion semantics pass an independent 32852-codec/1058-primitive rational
oracle, long reductions and bounded layout analysis. This is validation tooling,
not a runtime solver implementation or performance result.

The compact codec uses FP32 h/l, an integer tail in [-8,8] with explicit weight
and a symbolic exponent. Raw FP16 tails still underflow. Arithmetic intermediates
use the distinct 24/24/16 positional format; they do not inherit the input codec's
small-tail bound. The accepted exact accumulator needs 67 u64 magnitude limbs at
the maximum admitted dot length and is a costly CPU control, not a proposed GPU
default. GPUP-EXEC implements a separately admitted signed 256-bit exact-dot
subset with a proven exponent window and its own instruction/differential/sanitizer
gates. That subset still retains FP64 solver state. Persistent expansion solver
state remains untested.

SPEC-0021 refinement remains draft. Its inner-oracle/progress assumptions,
quantitative policies, interfaces and resource caps still need acceptance. Removing
mandatory final original-model certification would not meet the project's authority
contract. No preset or new GPU allowance follows, and historical gaps below remain.

## Convergence acceptance labels corrected during PR self-review

A CPU-only reproduction swapped tuned-FP64 and precision-FP64 acceptance labels
while retaining valid endpoints and numerical digests; the original independent
archive check accepted them. The reviewed report binds each acceptance endpoint
back to its model, configuration, work limit, profile flag and code object. COPT
checks also bind the original min/max model with offset seven, options, native
parameters and dependency identities, and recheck profile state/work equality.
Measured acceptance workers, endpoints, study results and GPU accounting are unchanged.
The reproduction, regression tests and integration checks remain under
artifacts/gpup-convergence-integration-20260930.

## Convergence costs and incomplete FP32/mixed coverage

The [convergence report](../docs/benchmarks/lp-convergence.md) retains all 176
attempts and independently verifies 174 endpoints; 87/104 primary timings certify.
On irregular-32768, accumulation FP32 saves about 10% of the measured device host
cost per proposal in short profiles but consumes 40464 proposals without certifying
in the full profile; precision FP64 certifies after 1600. This does not establish
a certified latency benefit. Reference arithmetic, audits/probes and original-model
assessments remain material for adaptive policies. No preset or tuning follows.

Two dense-65536 accumulation-FP32 timings (repetitions one/two) time out without
endpoints; empty output and partial worker receipts remain. Every mixed-65536 primary
sample is uncertified and its single repetition has no repeatability interval.
Deliberate bounded-work profiles retain work-limit outcomes. No admitted identity
was retried; no failed sample is promoted or used in certified ratios. Full native,
regular device, fixed-work/replay and COPT min/max/profile acceptance pass. CPU-only
review repairs prevent pre-refusal activity writes, retain non-object partial JSON
and leave missing worker cost envelopes unavailable, with exact source bindings.
Historical tuned_cases racecheck, large-session, mixed-model and opaque COPT graph
gaps remain. GPUP-7 requires an accepted numerical/resource contract first.

## COPT adapter interruption recovery corrected during integration review

Self-review reproduced unbound partial artifacts after coordinator interruption.
Recovery now binds retained files and surviving worker observations, and the report
accepts the ledger's conservative full reservation charge without treating a
recovered trial as successful. CPU regressions cover partial outputs, surviving
receipts, crashes after settlement, substitution and no retry. The declared review
corrections do not alter measured workers, results, defaults or GPU accounting.

## Bulk COPT preparation outweighs native loading savings

The [adapter report](../docs/benchmarks/lp-copt-adapter.md) verifies all 84 attempts
and certifies 42/72 timings. The bulk adapter is slower in every certified cell:
dense GPU PDLP median 11.070 versus 8.983 seconds. Native loading is cheaper, but
CSC preparation (including a repeated guard scan) and cold SciPy import outweigh
the saving. This implementation is experimental; no preset follows.

All 18 CPU-default extension timings and two profiles are interrupted at the
process deadline; native work differs, so their nine timing pairs and two profile
comparisons do not establish numerical/work equivalence. All 12 mixed-65536 PDLP
timings are numerically rejected. The other 27 timing pairs and ten profile pairs
match bitwise. Twelve native readbacks, 24 certified acceptance endpoints and
full native/source-only gates pass. Initial schema-enum and readback API failures
are corrected with receipts retained. Detailed per-trial driver/thermal telemetry
was not sampled and is explicitly unavailable; native GPU identity/execution and
lease admission activity are retained. Original wrappers, records, runtime kernels,
old racecheck/session and mixed-model gaps remain. GPUP-CONVERGENCE is next.

## Fresh primary contexts do not show a consistent latency benefit

The [GPUP-SETUP report](../docs/benchmarks/lp-fresh-setup.md) verifies all 32 attempts,
certifies 24 timings and matches 16 numerical/work comparisons. Primary retain/release
still takes about 170–189 ms in these separate profiles; it does not remove fresh
context work. Three paired intervals span one; direct irregular-32768 shows a small
scoped slowdown (user/primary 0.9947, 95% interval 0.9845–0.9948). User contexts remain
the default. The experimental primary path requires an inactive context and inherited
lease, with checked cleanup and separate setup receipts. No persistent reuse or preset.

All native, regular device and four primary-scope sanitizer gates pass, along with
twelve fixed-work pairs/replays. No actual GPU attempt failed or was retried; one
initial CPU lint failure was corrected and retained. Historical mixed-65536, large
sessions and tuned_cases racecheck gaps remain open. Optional COPT adapter and
convergence diagnosis are the next separately bounded tasks.

## Adaptive host-cost results are scoped; reference arithmetic remains

The [GPUP-ADAPTIVE-COST report](../docs/benchmarks/lp-adaptive-host-cost.md)
verifies all 32 attempts, certifies 24 timings and preserves 16 numerical/work pairs.
Full ladders prepare two operators rather than five; audits stream comparisons and
probes borrow state where narrowing is unnecessary. Reference FP64 updates, sparse
probe arithmetic, checkpoints, recovery and original-model assessments remain.
Only small-4 and irregular-32768, two policies and three development repetitions
were measured. Small-4 direct regresses (paired baseline/repaired ratio 0.7652,
95% interval [0.7336, 0.8291]); its cause remains unestablished. No preset or universal speedup is selected. Mixed-65536, old large
sessions and the historical tuned_cases racecheck gap remain open; fresh setup,
optional COPT construction and convergence diagnosis are separate tasks.
The initial CPU lint and source-only fixture failures are corrected, with receipts
retained. All device attempts passed; no study identity was retried.

## GPUP-HOST scope and latency uncertainty

The [host-input report](../docs/benchmarks/lp-immutable-host-input.md) verifies all
28 attempts and certifies 24 fresh timings, but the small-4 and irregular-32768
paired intervals span one. The large-model result is scoped to three development
repetitions. No general preset follows. The repair removes one duplicate model
parse/validation; sparse construction and all candidate/certificate assessments
remain fresh. Remaining adaptive reference arithmetic, mixed-65536 timeouts, old large-session gaps
and the historical tuned_cases racecheck receipt remain unresolved.

## Compact evidence repairs output coverage; mixed-65536 remains time-limited

The [GPUP-EVIDENCE report](../docs/benchmarks/lp-compact-evidence.md) retains all 24
fresh timing attempts. Compact verifies 12/12 and certifies 9/12, including all
irregular/dense 65536 cases; legacy verifies/certifies 3/12 and retains nine 32 MiB
partial files. All three compact mixed-65536 outcomes verify as interrupted, but
the workers timed out and remain unsuccessful. No large-model paired speed ratio
is available when its legacy member failed. Historical COPT samples are unchanged.

Four CPU full-witness fixtures fit below the unchanged cap; two are explicit
synthetic codec fixtures, never solve results. No solver arithmetic/kernel,
numerical setting, preset or session behavior changed. Existing tuned_cases
racecheck, session and COPT graph limitations below remain open. The first full
CPU gate exposed an overly broad historical-schema test; it now enumerates the
old revision and still checks exact bytes/deletions. Failed and passing receipts
are retained in artifacts/gpup-evidence-acceptance.

## COPT comparison: large evidence output and opaque graph internals

The [component report](../docs/benchmarks/lp-copt-comparison.md) retains all 1140
attempts, 948 verified endpoints and 402/816 certified primary samples. At 65536
rows, the frozen 32 MiB per-file output limit truncates project endpoint writes:
148 partial endpoint files remain, 142 exactly at the cap (82 process failures
and 60 also classified timeout), plus six killed partial writes. The trace-only
512 MiB allowance does not fill primary cells. Compact versioned evidence and its
separate GPUP-EVIDENCE comparison are now complete above; no historical output
limit or result was changed post-result. Other failures include deadlines, work limits and numerical rejection.

The archived verifier initially applied the ordinary 16 MiB cap to endpoint reads
despite explicit 128 MiB study input. The final reader repairs that omission and
independently verifies all 88 retained affected endpoints, recovering 37 certified
outcomes (21 primary), without changing trials, solving again or relaxing checks.
COPT native optimality still does not replace the original-model certificate;
both PDLP modes on mixed-65536 fail that certificate at 1e-9.

All 20 CUDA captures export, but COPT graph granularity leaves internal graph
kernel counts/durations and exact busy time unavailable. Native CPU phases remain
opaque and hardware-counter/CPU-sampling restrictions remain. Offline import
initially appended telemetry to captures and failed checksum validation. Exact
pre-import SHA-256 reconstruction recovered all 20 originals, with mutated copies
and recovery evidence retained; future imports use copies. Tests reject any
reconstruction that cannot match the complete historical hash. Historical
`tuned_cases` racecheck and old large-session limitations below remain open.

## GPUP-6 comparison coverage is incomplete; no preset selected

The [adaptive report](../docs/benchmarks/lp-adaptive-gpup6.md) records the frozen
comparison and every retained failure. An initial archive omitted the unchanged
scheduling code image required by CUDA discovery, causing 288 missing-evidence
attempts before LP execution; coordinator interruption also retained partial
attempts. The image was restored with a hash-bound repair record, and only
unattempted identities resumed. No failed trial was retried or hidden. Archive
preflight now checks all four required images before admission. The earlier v5
configuration-enum preflight failed before any reservation and is also preserved.

These missing cells cannot establish a performance ranking. Work-limit and
numerical-rejection endpoints are independently verifiable but remain uncertified.
The implemented opt-in recovery policies pass host fault injection, regular
device differentials, v5 verification/replay and all four adaptive sanitizers;
no general preset follows from those correctness gates. Adaptive throughput
sessions and disk checkpoints remain out of scope. The previous 65536-row
throughput timeouts and historical tuned_cases racecheck gap below remain open.

## PR #8 clean-checkout budget test failure corrected

Both initial CPU workflows failed because the throughput budget-authority test
read the ignored local GPU campaign ledger. A checkout with retained study data
masked that dependency. The test now uses a temporary root, unchanged checked
source/decision/authority files and a valid synthetic CPU-only ledger. Real
checksum, ceiling, prefix and output-binding rejection checks remain enabled;
all three budget tests pass in a fresh source checkout with no campaign artifacts.
The frozen production pins are still checked separately. No production accounting
code or live campaign data changed. Initial CI failure and clean-checkout receipts
are retained in artifacts/gpupt-integration-20260922; final integration still
requires the complete native gate and GitHub's required checks.

## GPUP-THROUGHPUT review findings corrected

The [correction report](../docs/benchmarks/lp-throughput-corrections.md) closes
all four 2026-09-22 review findings: all tuned outcome identities are stamped;
batch verification rejects mixed method/code identities and fallback; binary64
comparisons distinguish signed zero; and 48 new ordinary fresh-variant controls
verify 360/360 retained variant comparisons. The historical N=1 controls remain
labeled as such. Existing large-model and sanitizer limitations below remain.

## GPUP-THROUGHPUT: 65536-row short batches time out; tuned_cases racecheck incomplete

The [repeated-solve report](../docs/benchmarks/lp-repeated-solve-throughput.md)
verifies 687 of 705 admitted attempts. The 18 unverified attempts are the
65536-row N=8 short batches (batch-repeat-short and batch-variant-short on
irregular-65536, dense_block-65536 and mixed-65536, research-fused-fp64): each
was stopped at its 58-second supervisor reservation with no endpoint written.
At the original study revision, irregular-32768 completes but its amortized per-solve time (6.09 s) exceeds its
fresh single-solve latency (3.95 s): sessions do not pay off at that size with
200-proposal solves, and a batch of one does not pay off anywhere (paired ratio
0.67-1.04). Every 200-proposal short block terminates at the work limit, fresh
and batched alike, so no short block claims a certificate. The pre-existing
tuned_cases filter lacks a clean racecheck receipt: the run exceeded its
90-second reservation after study_observation and matched_control passed with
zero hazards, and the frozen 600-second acceptance cap (then 61.6 seconds left) could
not fit a rerun. The SPEC-0014 session_ scope passed all four sanitizers
including racecheck, and tuned_cases passed the other three; the partial
receipts are retained. Reproduce with benchmarks/configs/lp-throughput-v1.json
and the archived measured executables.

The subsequent [host-input repair](../docs/benchmarks/lp-throughput-host-input.md)
reduces the two scoped 32768-row N=8 batch process times to 10.746 s (repeat)
and 22.484 s (bounds variants), with all 16 results bitwise identical and both
old/new independent verifiers passing. These one-repetition diagnostics do not
rerun 65536-row coverage or establish a current paired single-vs-batch speedup;
the historical timeouts and tuned_cases racecheck gap remain open.

## Consumer Blackwell runs FP64, double compares and 64-bit conversions at 1/64 rate

The [root-cause note](../docs/benchmarks/lp-fp64-pipe-root-cause.md) shows that every
scheme recombining FP32 partials in FP64 is bound by the sm_120 FP64 pipe, that the
guarded research FP64 control is 2.4x slower than tuned for the same reason, and
that the twelve development instances are launch-bound. Hardware counters remain
unavailable (`ERR_NVGPUCTRPERM` even as root), so pipe attribution rests on static
instruction counts plus timing. GPUP-5C addresses the removable costs under
[ADR-0022](../docs/decisions/ADR-0022-fp64-pipe-execution-and-tolerance-tiers.md);
context creation (about 208 ms per solve) remains outside every arithmetic change.
Do not extrapolate dense Tensor Core or data-center FP64 throughput to this host.

## GPUP-5C: double-float underflows on scheduling LPs; large instances are host-bound and CLI-refused

The [GPUP-5C report](../docs/benchmarks/lp-fp64-pipe-gpup5c.md) verifies 806 of 850
admitted attempts; 24 planned attempts are missing because the 1500-second study cap
was reached, and 44 admitted attempts have no endpoint (34 CLI refusals of inputs
above the SPEC-0005 16 MiB bound, 10 research 30-second timeouts on mixed-65536).
`doublefloat-fp32` certifies 24/36 at 1e-9 and 27/36 at 1e-6 and 1e-4: its losses are
strict nonzero-to-zero product guards on scheduling-20x5 (1e-9 only), scheduling-50x10,
ta001, ta011 and mixed-65536, where FP32 products of decaying iterates fall below
the binary32 normal range. Do not weaken that guard; a block-exponent or per-vector
scale is the prerequisite. Fused FP64 is slower than integer-guarded separate FP64
on 32768-65536-row instances because its per-block update warp serializes eight
rows' vector arithmetic. On those instances preconditioning and research preparation
cost about one second each, dwarfing kernel time; the CLI cannot read them at all.
Tolerance tiers 1e-6/1e-4 recover FP32 storage coverage to 24/36 and 30/36 but do
not change certified latency materially. Reproduce with
benchmarks/configs/lp-research-v2.json and the archived measured executables.

## GPUP-5B exact representations recover coverage but component arithmetic is slower

The [840-attempt research study](../docs/benchmarks/lp-exact-components-gpup5b.md)
restores 27/36 certified timings with exact power-of-two/factored FP32 storage
and with two/three-component products, versus 12/36 for ordinary scaled FP32
storage. Existing runtime behavior and old failures remain unchanged. All new
modes still exhaust work on scheduling-50x10, ta001 and ta011. Power-of-two scaling
increases proposals on four development instances and its current extra host
preparation costs time. Three-component cross-products take 2.69x/2.67x the native
research update time on irregular-2048/dense_block-1024 and increase certified
solve latency by 10.4%/13.8%. Exact representation is not an acceleration result.
Two-component truncation works at these targets on this corpus; no universal
accuracy guarantee or supported preset follows.

The isolated prototype splits vectors per nonzero, stores per-coefficient exponents,
and performs many FP64 compensated additions to recombine FP32 product/error pairs.
Packing and metadata add storage/transfers; all are charged. Matched reconstruction
controls and traces separate these costs from convergence. Hardware counters remain
unavailable; no bandwidth/occupancy explanation is asserted. Raw traces initially
need offline import with the existing isolated libdw; all 24 decode and match
1200 launches without rerunning GPU work. No missing endpoint, numerical failure,
timeout or fallback occurred among these 840 attempts. All old artifacts and the
3288-event prefix are unchanged. See the preserved
[rounding note](../docs/benchmarks/lp-fp32-rounding-analysis.md) and
[candidates](../docs/plans/lp-precision-candidates.md). GPUP-6 requires its own
bounded adaptive contract; no recovery or guard relaxation is implicit here.

## GPUP-5 FP32 coverage loss and external-control limits

The [verified GPUP-5 study](../docs/benchmarks/lp-fp32-gpup5.md) retains all 480
attempts. Matched/tuned/precision FP64 certify 27/36 timings; FP32 storage,
products, accumulation and fixed master correction certify 12/36, and FP32 working
state 6/36. Storage-only modes exhaust work; product modes stop on guarded
nonzero-to-zero product loss. Fixed correction every 32 steps does not restore
coverage and can substantially increase transfers and host work. Reproduce with
benchmarks/configs/lp-precision-v4.json and the archived measured source. Next:
GPUP-6 must specify adaptive audits/recovery before changing numerical behavior;
do not weaken guards, tolerances or work limits to hide these outcomes.

The [bounded follow-up diagnosis](../docs/benchmarks/lp-fp32-slowdown-diagnosis.md)
retains 196 equal-work short runs, 14 decoded CUDA traces and three unsuccessful
hardware-counter attempts. FP32 iterations are similar or sometimes faster than
the precision FP64 control, but the failed large cases do 22–31 times as many
proposals. Exact rational row activities identify scaled-matrix bias above original
allowances; this does not explain every nonconverged model. Generic guarded kernels,
six launches/update, frequent state readbacks and host correction add costs. Hardware
counters are unavailable (ERR_NVGPUCTRPERM); cache/bandwidth/occupancy attribution is
unresolved. Saved traces decoded offline with the existing isolated libdw dependency.
No solver behavior or guard changed. Historical reporting now accepts an intact,
settled archived ledger prefix so later diagnostics cannot change GPUP-5's totals.

COPT 8.0.6 CPU/GPU PDLP certify 27/36 and 24/36 timings. Scaling-256 remains
feasible but unclosed; GPU ta001 witnesses are rejected by original-model checks.
Its public API exposes neither a PDLP iteration-limit nor a seed control: record
observed counts above 50000 as work_limit and enforce the common process deadline.
Input coefficients at or below its nonzero 1e-10 threshold are refused rather than
silently dropped; all frozen study coefficients exceed it. Native status and a
requested GPUMode never establish host certification or actual GPU execution.
Isolated setup phase timing is unavailable; native rounded solve time and combined
setup/export/validation/startup overhead are recorded separately. COPT remains
optional study tooling. Presolve-only or CPU fallback is not a GPU success.

HiGHS scaling-256 run errors and irregular-2048 timeouts remain in this study, as
do host time/work limits. Preflight callback/log-parser failures are retained in
the separate acceptance ledger. All six precision cases pass all four sanitizers
on the original measurement GPU; GPUP-4's historical device limitation stays below.

## GPUP-4 launch setup failure, correction and remaining limits

The first 320-attempt round lost 24 matched-reference timing endpoints because an
archived executable was copied without execute permission. Its bytes were intact;
permission repair enabled subsequent attempts. All failed attempts and charges
remain. ADR-0018 preserves that interim round and freezes one separate complete
correction, with identical numerical settings/seeds/order/device and no new GPU
allowance. All 320 correction attempts have verified evidence: 248 certified,
66 work-limited, six host timeouts. Each configuration certifies 27/36 timings.

Both rounds charge 456.586499157 additional GPU seconds; canonical campaign total
902.574545061. The original 622-event prefix, authority and output binding remain.
Executable preflight, mode-preserving copies and prior-prefix verification prevent
silent recurrence or ledger reset. A final schema regression also caught and fixed
object-wrapped execution enum names; string-only parsing now matches the schema.

The [reviewed report](../docs/benchmarks/lp-tuned-fp64-gpup4.md) retains negative
ablation results and unchanged scheduling convergence failures. Transfer savings
do not consistently improve latency; context startup remains substantial. Matched
FP64 stays the general reference, with fused-warp provisional only on the three
named development instances. Three repeats, unadjusted intervals and no held-out
measurement do not support a universal preset. Final parser validation was repaired
after measurement; the report identifies the exact measured source/executable.

## GPUP-4 sanitizer device differs from the frozen measurement device

Acceptance on 2026-09-15: all 41 regular device cases pass on the selected RTX 5090.
Memcheck failed to allocate instrumentation while it reported 31314 MiB used and
797 MiB free, with no process visible from this workspace. The documented
force-synchronization-limit 8 retry also failed. Both failed attempts are retained.

The separate acceptance budget then used an idle sm_120 RTX PRO 6000 Blackwell
GPU-6721b13a-30f9-83ec-dace-ba2d9738556f, under the same shared host lease. All 41
regular cases and eight scoped cases under each of memcheck/racecheck/initcheck/
synccheck passed; zero errors and zero racecheck warnings. CLI evidence, fallback
and replay also passed. This is sanitizer coverage on the named compatible device,
not a claim that the memory-constrained RTX 5090 sanitizer run passed. Measurement
remains on the frozen RTX 5090 UUID. Evidence: artifacts/gpup4-acceptance.

## LP certification can lose the roundoff allowance at zero reduced cost

Resolved by GPUP-1 on 2026-09-14. Discovered during the GPU LP precision design
review and preserved by GPUP-0, this affected the shared host certification used
by both host-lp and cuda-lp, independently of future quantization. The original
counterexample below is retained for reproduction against the previous revision.

The previous variable loop in `crates/optimizer-lp/src/certify.rs` used bound zero
when a computed reduced cost rounded to zero, then multiplied the reduced-cost
error allowance by that chosen bound. The reduced cost can be nonzero in exact arithmetic
over the stored binary64 coefficients, so the required allowance is lost.

Reproducer (continuous variables, equality constraint):

```text
minimize 0.1*x1 + 0.30000000000000004*x2
subject to x1 + 3*x2 = 0
-3e16 <= x1 <= 3e16
-1e16 <= x2 <= 1e16
dual multiplier y = [0.1]
feasible candidate x = [3e16, -1e16]
```

The pre-repair built-library diagnostic returned bound 0 with allowance 0. The
candidate passes the existing feasibility check; ordinary FP64 objective evaluation
reports -0.5. Exact rational evaluation of the *stored binary64* coefficients at
that candidate is `-152587890625/549755813888`, approximately
-0.27755575615628914. Thus zero is an invalid lower bound even for a finite boxed
model; the ordinary objective's -0.5 also illustrates why objective/gap arithmetic
needs review. These values are a correctness counterexample, not timing evidence.

Resolution: [GPUP-1](../docs/plans/gpu-lp-precision-roadmap.md#implementation-slices)
replaces the scalar allowance estimate with finite outward enclosures for every
product, reduction, reduced cost, bound contribution, and final sum. Uncertain
signs use both variable-bound sides; an unusable infinite side yields no finite
certificate. Exact zero remains usable even for a free variable. Both backends
share an outward objective/gap check with the correct maximization direction and
finite conservative tolerance arithmetic. The reported objective and the existing
feasibility tolerance policy are unchanged.

Evidence is in [active task](active-task.md). The original cancellation and free
variable cases failed before the repair. Independent rational fixtures and the full
native CPU gate cover the numerical contract. Integration acceptance added all
regular device suites; full memcheck, initcheck, and synccheck for all three suites;
full racecheck for CUDA/scheduling; and 11 LP racecheck cases, all with zero errors.
The long publication case completed in an earlier partial racecheck run. The broad
run was subsequently stopped during the existing atomic-reduction negative-control
stress case. That stress case remains an explicit sanitizer coverage limit accepted
in the integration review for unchanged kernels; the full broad gate is not claimed
as passed. The original RTX 5090 scoped sanitizer evidence remains valid. No GPU
kernel or experimental precision mode changed.

Remaining limit: outward enclosures can be wider than necessary because they lose
correlations. A finite boxed model may refuse certification after intermediate
overflow, and uncertainty can prevent certification on an infinite side even when
the exact reduced cost is zero. This is a conservative refusal, not a proof that
the LP is unbounded. Feasibility and the objective field remain tolerance-based
binary64 computations, not exact-rational primal certificates. See
[the numerical argument](../docs/architecture/lp-certification.md).

## GPU LP precision experiments and recipes are not implemented

GPUP-2 now implements the bounded LP-only harness under accepted SPEC-0013 and
frozen ADR-0014. The [development baseline](../docs/benchmarks/lp-baseline-gpup2.md)
records 144 trials and 173.148261443 GPU seconds. Existing CUDA FP64 certified only
the two small witness instances at the selected targets; host LP certified nine
instances and HiGHS ten. Larger GPU cases reached work/time limits, HiGHS failed
scaling-256 and timed out on irregular-2048, and host LP timed out on three
scheduling cases. These unsuccessful outcomes are preserved evidence, not
infrastructure gate failures or permission to weaken numerical targets.

GPUP-5 implements precision settings and bounded FP32 comparisons under accepted
SPEC-0012/0013 and ADR-0019. cuda-lp-quantized, adaptive recovery, lower-width
quantization and supported recipes remain unavailable. Opt-in cuda-lp-matched shares
host control. Legacy cuda-lp retains fixed control. The
[matched study](../docs/benchmarks/lp-matched-fp64-gpup3.md) certified 27/36 timing
trials for both matched CUDA and host, versus 6/36 for legacy CUDA. Scheduling-50x10,
ta001 and ta011 remain uncertified at 50,000 matched iterations; no finite gap is
claimed for them. Small cases remain slower on GPU because setup dominates.
Certified per-instance paired timings establish bounded development evidence only.
The independent exact-rational certification regressions remain authoritative.
The section heading retains its earlier link identity; the missing experiments
here are later precision/recovery comparisons and recipe selection; GPUP-5
FP32 comparisons are now implemented and measured.

Follow [the backlog](backlog.yaml) one slice at a time, preserving the study ledger
and all failures. Validation and held-out models were generated/hash-checked only;
existing Taillard observations remain development diagnostics. Later campaign
migrations must carry forward consumption within the unchanged eight GPU-hour cap.
The general C10 runner remains unspecified. Repeated-solve throughput and full MILP
performance need separate specifications and budgets. No implementation failure
has been accepted as a waived gate.

## GPU LP latency and harness overhead are measured limitations

The [follow-up diagnosis](../docs/benchmarks/lp-gpu-slowdown-diagnosis.md) reproduced
the GPU's slow convergence bit-for-bit on the host for irregular-256 and scaling-64.
The fixed GPU controller differs from the adaptive host controller. Repeated host
certification consumed 7.369 of 9.276 seconds on irregular-2048; its padded
1,024-entry reductions perform extensive work on short sparse columns. Small
fresh-process solves are dominated by device startup. Transfers were a minor cost
on the measured instances; the kernel source's idealized bandwidth argument does
not account for padded work and is not a measured bottleneck classification.

The ADR-0016 tooling follow-up now compiles one strict immutable schema snapshot
per process and waits for quiet telemetry with bounded post-lease admission.
CPU simulations, full pinned-native gate and the supplementary study pass. One
invocation completed all 160 attempts, with 55.606 seconds of pre-reservation
activity waiting. The same-catalog ledger validation falls from 166.575 ms including
a fresh snapshot to 0.067 ms with reuse; large document validation remains a cost.
The bit-preserving certifier cuts irregular-2048 certificate cost from 26.455 to
2.198 ms, with independent rational and padded-oracle regressions preserved.
Historical diagnosis: Python validator construction
rechecked all schemas for every event/result; ledger
replay and report generation repeat that overhead. The activity guard can pause
on a recent utilization sample from the project's own completed job. Four
supplementary invocations paused and resumed without repeated trials. Proposed
fixes preserved schema strictness, shared-lease exclusion and host numerical
authority. GPUP-3 is complete; GPUP-4 is next. The original diagnosis changed no
solver behavior. Supplementary study spending is 251.845179881 GPU seconds, bringing
the canonical cumulative ledger to 445.988045904 seconds. Original records remain
unchanged. Endpoint-v2 controller-phase schema omission was caught in acceptance,
fixed with a CPU regression and verified by the affected leased CLI rerun; no
required check is waived.

Seven supplementary jobs added 20.994604580 GPU seconds, including profiler export
failures. Cumulative campaign use is 194.142866023 seconds. Raw traces were recovered
offline using a privately extracted importer dependency; all seven endpoints and
both 1,200-launch trace counts verified. CPU call-stack sampling and GPU
bandwidth/occupancy counters were unavailable or not collected, respectively.

## Legacy HiGHS LP best_bound is not independent certificate evidence

GPUP-2 endpoint checks observed the existing adapter reporting best_bound 0 for
examples/lp-model-v1.json while its validated minimum objective is -3.5. The
adapter reads mip_dual_bound even for an LP; the pinned library can return a
finite MIP-only default, preventing the adapter's objective fallback. This field
must not be treated as a conservative LP certificate. The owned executive already
uses the objective of an optimal relaxation rather than this field.

Reproduce with optimizer solve --backend highs on examples/lp-model-v1.json and
examples/solve-config-v1.json. With --lp-evidence, the new independent endpoint
certifies -3.5 from native row multipliers; it never uses the legacy best_bound or
native optimal status as certificate evidence. Both objective senses are tested.
Existing solve-record meanings and runtime defaults are preserved in GPUP-2.
A separate bounded adapter-contract repair should address the legacy LP field;
this does not block the independently certified LP study endpoint.

## Source planning references

The preserved ai-native-optimizer-plan.md references optimizer-survey.md and
llm-or-survey.md from another session; neither is present. Reproduction:
inspect its Background links. Next diagnostic step: recover those source surveys
if research work needs them. The maintained documentation book excludes the two
original planning inputs from recursive link validation.

## LP integration CI fixtures

On 2026-09-16, post-merge CPU CI run 35041476887 correctly timed out the
coordinator-loss fixture but recorded 1.340948131 leased seconds against its
one-second assertion. That assertion imposed a second wall-clock ceiling on
teardown and durable output, independent of the requested 0.1-second solve and
cleanup limits. The fixture now retains its existing three-second completion wait
and checks timeout signal timing, terminated child status, lease coverage of full
elapsed work and nonblocking lease reacquisition. Production supervision, study
limits, charged overruns and all GPU behavior are unchanged. The failed hosted log
is retained in artifacts/gpup4-pr-integration/main-ci-failure.log.

Resolved during GPUP-2/3 PR review on 2026-09-15. The new archived-schema regression
needs the e415918 Git tree, so CPU CI now fetches full history. A fresh native gate
also exposed a startup-dependent lease test: its 150 ms parent sleep included
worker imports, leaving only 40.380 ms of actual queue wait against a 50 ms check.
The test now waits until the worker opens the lock, then measures held-lease delay
and asserts no solve output opens before release. Ten consecutive targeted runs and
a full pinned-native gate pass. Production lock and supervisor code did not change.

## External configuration

The origin remote is https://github.com/liuyumou/OptForge.git. Main protection is
configured and verified as of 2026-09-16 under the active
[Protect main ruleset](https://github.com/liuyumou/OptForge/rules/23515452): required
PRs, up-to-date GitHub Actions cpu/docs/smoke checks, resolved conversations, no
force pushes or deletion, and no bypass actors. Human approval is not mandatory.
See [release operations](../docs/operations/release.md#protected-main). Labeled GPU
runner provisioning and artifact retention remain separate hosting administration.

Publication state (verified 2026-09-15): GPUP-2/3, the baseline diagnosis and the
CI/test review fixes are published and merged in
[PR #2](https://github.com/liuyumou/OptForge/pull/2), merge commit 3c8d1ff.
All six hosted CPU/docs/smoke runs passed for reviewed head faf4a90. The author's
self-review is recorded on the PR. Original implementation/reference commits are
preserved; local main was synchronized and both completed branch copies deleted
after ancestry verification. The maintainer authorized these operations; no
hosting/protection change or additional GPU study work occurred.

Publication state (verified 2026-09-14): GPUP-0/1 and the CI cache correction are
published and merged in [PR #1](https://github.com/liuyumou/OptForge/pull/1), merge
commit `2c84a95`. The original slice commits are retained on main, local main was
synchronized, and both completed local branches and the published feature branch
were removed after ancestry verification. Earlier local-only publication statements
remain historical records. The maintainer explicitly authorized publication,
self-review, merge, and cleanup; AGENTS.md's authorization rule is unchanged.
See [active task](active-task.md) for acceptance, CI, review, and cleanup evidence.

## No dispatch threshold is committed, for either specification

SPEC-0010 requirement 22 and SPEC-0011 requirements 18 and 19 ask the same thing of
two different decisions, and neither is answered by a committed number.

The crossover is recorded below and no default reads it. Dispatch is the caller's
explicit `device` field, or for a backend the explicit `--backend` flag: there is no
threshold anywhere that compares a model against a measurement and chooses. "CPU
remains the default below the measured crossover" therefore holds because CPU is the
default everywhere, not because anything measured.

For SPEC-0011 the position is the same and the mechanism is even simpler: there is no
threshold document, no `Default` for one, and no code path that could promote a solve
to another backend. The pinned CPU backend is what runs when nothing is named.

That is deliberate rather than outstanding work. A dispatch threshold is an
acceptance-shaped number -- it decides what runs where, on evidence from one host --
and the benchmark protocol requires an ADR and an experiment record before a
threshold like that is committed. Recording the measurement and leaving the choice
to the caller is the honest intermediate state.

Reproduction: `grep -rn "crossover" crates/` finds only comments, and
`optimizer solve` with no `--backend` reaches `highs`, asserted positively by
`the_default_configuration_reaches_the_pinned_backend`. Next step: an ADR proposing
a threshold, with the held-out evidence Stage 4 asks for rather than the single-host
diagnostic recorded here. One ADR can cover both decisions or they can be split;
what neither may do is commit a number without that evidence.

## A fallback cannot be verified field for field

SPEC-0011 requirement 20 requires an availability failure to fall back to the CPU
backend and produce "the same conclusion". That is satisfiable for the conclusion and
is not satisfiable for the record. A fallback writes a record naming `highs` where the
caller asked for `cuda-lp`, so `backend`, `backend_version` and `lp_settings` all
differ, and `optimizer verify` compares those fields.

So a run that fell back is reproducible only in the sense that re-running it reaches
the same answer, not in the sense that its record matches one from a run that did not
fall back. `an_availability_failure_falls_back_to_the_pinned_backend` asserts the
conclusion and asserts explicitly that the two records name different backends, rather
than asserting an agreement that does not hold.

The related entry above -- verification assuming an unchanged native library -- is the
same shape of limit arriving from a different direction.

Reproduction: point `CudaLpBackend::open_with_code_object` at an absent code object and
compare the record it writes with the pinned backend's. Next step: none proposed. A
record that recorded "asked for A, ran on B" would make the divergence describable, but
that is a SPEC-0005 change and needs its own contract.

## A device that cannot be opened is refused, not fallen back from

The two rules meet here and the boundary between them is a choice this implementation
made rather than one either specification states outright. A device that cannot be
*opened* -- absent, hidden by `CUDA_VISIBLE_DEVICES`, or not leased -- is a refusal,
because SPEC-0010 requirement 3 forbids a record claiming a device the run did not use
and the C6 device work already established that a GPU-naming configuration is refused
rather than silently run on the CPU. A device that opens and then cannot do the work --
no code object, not enough memory -- is an availability failure and falls back under
requirement 20.

Both are defensible and they are not the same rule. A caller who mistypes a UUID gets
an error; a caller on a correctly named device with an unprovisioned code object gets a
CPU answer and a diagnostic. That difference is worth knowing before relying on either.

Reproduction: `optimizer solve --backend cuda-lp --device GPU-does-not-exist` versus
the same command with `AI_OPTIMIZER_CUDA_DIR` pointed at an empty directory. Next step:
none proposed; if the distinction proves confusing in use it belongs in SPEC-0011's
Errors and Recovery section rather than in code.

## Tolerances are reused as an optimality-gap policy

SPEC-0011 requirement 14 closes `Optimal` when a certified bound and a validated
candidate agree "within the caller's tolerances", and the only tolerances a caller
supplies are `absolute`, `relative` and `integrality` on the solve configuration. Those
are documented as a *feasibility* policy: they decide whether a candidate satisfies the
model. Using them as a duality-gap policy overloads them.

The practical consequence is that a caller who wants a strict feasibility check and a
loose optimality gap, or the reverse, cannot express it. Nothing is wrong today because
both uses want small numbers, and a gap field cannot be added without changing
`solve-config-v1`, which SPEC-0011 deliberately leaves at version 1.

Reproduction: read `assess` in `crates/optimizer-lp/src/backend.rs` against
`Tolerances`'s documentation in `crates/optimizer-core/src/evaluate.rs`. Next step: a
gap tolerance on the solve configuration, which is a schema change with the cascade
into `search-config-v3` that SPEC-0011's Compatibility section avoided.

## CPU/GPU bitwise identity is this project's property, not the contract's

SPEC-0011 requirement 8 asks only that a result be bitwise reproducible on a fixed
device and code object. The device suite asserts something stronger: that the device's
iterates equal the host engine's bit for bit. That is deliberate -- a tolerance on an
iterative method is nearly untestable, since one loose enough to pass at iteration ten
thousand hides a real defect at iteration ten -- but it is not contractual.

It holds because `-fmad=false` removes the device's only contraction, because Rust
never contracts, and because `log`, `exp` and `sqrt` are computed host-side and passed
in as scalars. A toolchain that broke any of those would break the assertion without
breaking the specification.

Reproduction: rebuild `lp_pdhg.cubin` without `-fmad=false` and run
`the_device_iterates_match_the_host_engine_bitwise`. Next step, if it ever breaks:
record which operation diverged and narrow the assertion to that operation, rather than
widening everything to a tolerance and losing the instrument.

## The LP device suite does not run in CI either

The entry above about device acceptance applies unchanged to the three device suites,
not two. `tools/gpu_check.sh` now runs `optimizer-cuda`, `optimizer-schedule-examples`
and `optimizer-lp-cuda`, and sanitizes all three under each of the four tools, but the
labeled GPU runner is still unprovisioned. Every result recorded for SPEC-0011's device
half is a local run on one host.

Reproduction: `.github/` contains no device job. Next step: unchanged -- provision a
labeled runner, or keep recording device evidence as local.

## A weak certified bound will have two causes

SPEC-0011's open question is whether a certified bound is ever strong enough to prune
usefully. On this project's own models that question cannot be answered cleanly yet,
because the flow-shop encoding's linear relaxation is already weak before any method
touches it -- which the entry on that encoding records.

So a weak bound on an encoded scheduling instance has two candidate explanations, the
relaxation and the certification, and attributing it to either without an instance
family whose relaxation is known to be tight would be wrong.

Reproduction: none needed; it follows from the two contracts. Next step: if the
question is pursued, measure on instances whose relaxation quality is known
independently, not on the frozen scheduling subset.

## Rebuilding a poisoned context is not implemented

Requirement 29 permits two responses to a sticky fault: destroy and rebuild the
context, or fall back for the remainder of the run. This implementation takes the
second. A residency that observes a sticky driver status marks itself poisoned and
refuses every later call without touching the device, and the device producer's
sweeps go to the host from then on.

The consequence is that one sticky fault costs a run its device even if the fault
was transient. Rebuilding would need the residency to replace a context its buffers
hold through an `Rc`, which is a lifetime problem rather than a driver one, and the
specification does not require it. Reproduction: there is no test that faults a real
device, because provoking a genuine sticky fault means corrupting one, so the
poisoning path is covered by unit tests over `DriverStatus::is_sticky` and
`DeviceError::poisons_context` rather than end to end. That gap is the honest one to
record: the decision logic is tested, the recovery from a real fault is not.

## Resolved: device sanitizer coverage runs and is clean

`bash tools/gpu_check.sh`, run under `tools/gpu_job.sh`, executes the device suite
and then all four `compute-sanitizer` tools over it. On 2026-09-13 on an RTX 5090:
memcheck 0 errors, racecheck 0 hazards, initcheck 0 errors, synccheck 0 errors.

This mattered more than a formality. The kernels are hand-written and index shared
memory from computed offsets, and the neighborhood kernel has two threads writing
disjoint halves of one dynamically sized array while 254 others wait on a barrier --
which is precisely the shape racecheck exists to find and precisely the shape a
reviewer cannot check by reading.

The script refuses to run without an inherited lease rather than taking one itself,
so it cannot be invoked outside the wrapper that names a single device. It is
deliberately not part of `tools/check.sh`: that gate is CPU-only and must stay so,
because almost every task record in this project states a "CPU only, no GPU
workloads" budget that a kernel-running gate would make false.

What is still uncovered: the C1 native-library sanitizer gap below is unrelated and
unchanged, and none of this has run in CI, because the labeled runner is not
provisioned. A local run is recorded as a local run.

## Device acceptance does not run in CI

The device suite is opt-in behind `AI_OPTIMIZER_GPU=1` so the ordinary gate stays
CPU-only and no task record's "CPU only, no GPU workloads" budget is made false by
it. The consequence is that device evidence exists only where someone ran it by
hand: the labeled GPU runner is still not provisioned, so no device test has ever
run in CI. Evidence recorded from a local run is recorded as such and must not be
read as a CI pass.

## Deferred hardware evidence

HiGHS differential tests are implemented and passing under C1; see
[active task](active-task.md). No solver performance or hardware claim is made, and
the crossover recorded below is a development diagnostic on one host rather than a
benchmark result.

## The device loses below roughly fifty jobs, and context creation dominates

The first crossover measurement, recorded here because both of its findings are
inconvenient and would be easy to leave out.

Measured on one RTX 5090, compute capability 12.0, 170 multiprocessors, release
build, best of three after a warmup, over the ADR-0011 scale split. The workload is
one full insertion neighborhood: for every job, the cost and position of its best
reinsertion. The CPU column is the tuned `insertion_neighborhood`; "resident" is the
device with the instance already uploaded and the context already created; "with
setup" is end to end from nothing, which is what the benchmark protocol requires be
reported and which no kernel-only number may replace.

| instance | shape | cpu tuned | device resident | device with setup | ratio |
| --- | --- | --- | --- | --- | --- |
| ta001 | 20x5 | 0.010 ms | 0.041 ms | 151.6 ms | 0.25x |
| ta011 | 20x10 | 0.019 ms | 0.043 ms | 151.7 ms | 0.45x |
| ta021 | 20x20 | 0.037 ms | 0.054 ms | 148.4 ms | 0.69x |
| ta031 | 50x5 | 0.063 ms | 0.054 ms | 143.9 ms | 1.17x |
| ta041 | 50x10 | 0.122 ms | 0.074 ms | 163.4 ms | 1.64x |
| ta051 | 50x20 | 0.230 ms | 0.087 ms | 162.3 ms | 2.63x |
| ta061 | 100x5 | 0.250 ms | 0.079 ms | 148.2 ms | 3.19x |
| ta071 | 100x10 | 0.478 ms | 0.095 ms | 147.1 ms | 5.03x |
| ta081 | 100x20 | 0.916 ms | 0.134 ms | 149.9 ms | 6.85x |
| ta091 | 200x10 | 1.898 ms | 0.159 ms | 146.8 ms | 11.97x |
| ta101 | 200x20 | 3.749 ms | 0.232 ms | 147.0 ms | 16.15x |
| ta111 | 500x20 | 23.868 ms | 2.507 ms | 148.7 ms | 9.52x |

The device loses at twenty jobs, by a factor of four. That row is the reason the
measurement is believable: SPEC-0010's acceptance list states it as the expected
outcome, and a report winning everywhere would have been evidence that transfers
were excluded. The crossover sits at roughly fifty jobs on this hardware, and
requirement 22 makes the CPU the default below it.

Context creation costs about 148 milliseconds and dwarfs every other number in the
table, including the largest CPU time. A device is therefore worth reaching only
when the context is amortized across many calls, which is requirement 16's residency
rule arriving as a measurement rather than as a design preference. Nothing in the
project currently amortizes it, because nothing dispatches to a device outside a
test.

The ratio peaks at 200 jobs and then falls, from 16.15x to 9.52x. That is not noise
and the cause is known: the head and tail tables are 80,000 bytes at 500 jobs by 20
machines, so only one block is resident per multiprocessor, and the per-block
recurrence is built by two threads while the other 254 wait. The kernel comment says
so and names the fix -- a max-plus scan across machines per step -- which is
deliberately not done, because correctness came first and an unmeasured optimization
would have had nothing to be measured against. The falling tail is what makes the
table worth keeping: a sweep that stopped at 200 jobs would have reported a
monotonic trend that does not hold.

These numbers are a development diagnostic on one host. They are not a benchmark
result, not evidence, and not a claim about the engine, and SPEC-0010 requirement 36
forbids reading the crossover as evidence that device execution improves a search.

## A device fault is outside every containment claim this project makes

The C3 extension host contains panics. A device fault is not a panic: an illegal
memory access in a kernel poisons the context, and a driver-level fault can end the
process. ADR-0009 records this as a cost of the boundary rather than solving it, and
SPEC-0010's security section states it rather than implying containment. A
device-backed extension therefore cannot be contained the way a CPU extension is, and
no per-device memory budget is enforced. Next step: the same process-isolated workers
the panic-only entry below already names, which would cover both cases and needs its
own decision record.

## Resolved: the flow-shop heuristics are a tuned baseline

`neh` and `insertion` evaluated each candidate insertion position by cloning the
sequence and re-running the whole recurrence, which is `Theta(n^3 m)` where
Taillard's exact head and tail acceleration is `Theta(n^2 m)`. That was the right
choice for C5, which claims correctness and forbids a performance claim, and it
became a problem only because Stage 4's entry condition requires baselines be tuned
before any intervention is measured: a device speedup over the naive pass would have
measured the pass.

The acceleration is implemented in
[the recurrence module](../crates/optimizer-schedule/src/evaluate.rs) rather than in
the heuristics, so requirement 8's rule that nothing proposing a schedule owns a
second definition of its cost still holds. The returned permutations are unchanged
and that is asserted by `accelerated_scoring_returns_the_naive_permutations`, which
compares against the pre-change algorithm scored by the independent oracle and
requires the same sequence rather than the same makespan. The weaker assertion would
have passed a real break: requirement 17 fixes which of several tied permutations a
caller receives, and two different permutations can tie.

The test was confirmed able to fail. Relaxing the insertion tie-break from strictly
less to less-or-equal — the exact mistake the acceleration invites, because the
rewrite moves that comparison — fails it, while
`construction_is_deterministic_including_under_ties` still passes, since a
deterministic wrong answer is still deterministic.

Measured on the development host, release build, best of three after a warmup, over
the whole ADR-0011 scale split, with a 0.19% noise floor from an identical binary:

| instance | shape | construction | improvement pass |
| --- | --- | --- | --- |
| ta001 | 20x5 | 0.18 ms to 0.03 ms | 0.16 ms to 0.04 ms |
| ta011 | 20x10 | 0.07 ms to 0.01 ms | 0.16 ms to 0.02 ms |
| ta021 | 20x20 | 0.12 ms to 0.02 ms | 0.31 ms to 0.04 ms |
| ta031 | 50x5 | 0.33 ms to 0.04 ms | 0.84 ms to 0.06 ms |
| ta041 | 50x10 | 0.64 ms to 0.07 ms | 1.70 ms to 0.12 ms |
| ta051 | 50x20 | 1.52 ms to 0.13 ms | 4.23 ms to 0.23 ms |
| ta061 | 100x5 | 2.29 ms to 0.13 ms | 6.26 ms to 0.25 ms |
| ta071 | 100x10 | 4.67 ms to 0.25 ms | 13.24 ms to 0.47 ms |
| ta081 | 100x20 | 11.26 ms to 0.48 ms | 32.49 ms to 0.92 ms |
| ta091 | 200x10 | 34.33 ms to 0.97 ms | 99.13 ms to 1.89 ms |
| ta101 | 200x20 | 87.05 ms to 1.89 ms | 257.39 ms to 3.75 ms |
| ta111 | 500x20 | naive not run; 11.98 ms | naive not run; 23.86 ms |

The improvement pass speeds up by roughly 4x at twenty jobs and roughly 69x at two
hundred, and the ratio tracks the job count rather than the machine count: ta061 and
ta091 differ only in jobs and their ratios differ by a factor of two, while ta061 and
ta081 differ mostly in machines and their ratios are much closer. That is what an
`O(n)` factor should look like, and it is the reason the whole sweep is in the table
rather than one row: any single instance would have supported almost any claim about
the shape of the improvement. The naive pass was not run at five hundred jobs, where
it takes minutes; that row reports the tuned time only and says so.

These are a development diagnostic on one host, not a benchmark result and not
evidence.

What this changes for C6 is worth recording, because it is the opposite of
convenient. The number a device now has to beat at 500 jobs is 23.86 ms of tuned
single-threaded CPU work, not the several seconds the naive pass would have taken.
The crossover, when it is measured, will sit further out than it would have against
the old baseline, and that is the honest position to measure from.

## Intermittent advisory database fetch

`cargo deny check advisories` fetches the RustSec database from github.com, which
has repeatedly been unreachable in this environment. The acceptance gate now
falls back to the cached database rather than failing spuriously or skipping the
check; an absent cache is still a hard failure. Reproduction: run
`cargo deny --locked check` without network egress to github.com. Next step: seed
the advisory database in CI so the check does not depend on egress at gate time.

## Native acceptance can be skipped explicitly

`AI_OPTIMIZER_SKIP_NATIVE=1 bash tools/check.sh` runs without the pinned HiGHS
build and prints a prominent warning that native acceptance was not covered. Such
a run is not a complete acceptance gate pass and must not be recorded as one.

## Sanitizers not yet in the gate

SPEC-0002's acceptance list mentions running repeated native lifecycle tests under
available sanitizers. The repeated-lifecycle test exists and passes, but no
sanitizer run is part of `tools/check.sh` yet. This is an uncovered part of the C1
acceptance list, recorded rather than waived silently.

## Extension containment covers panics only

The C3 extension host runs extensions in-process and contains panics with
`catch_unwind`. It cannot contain a process abort, stack exhaustion or a memory
fault, and it enforces no per-extension memory budget. A hostile extension can
therefore still take down the process, even though it cannot affect a search's
mathematical conclusion. Reproduction: an extension calling
`std::process::abort` ends the test process. Next step: process-isolated
workers, which SPEC-0004 defers and which need their own decision record. The
host also requires the unwind panic strategy; no repository profile sets
`panic = "abort"`, and nothing currently pins that.

## Python SDK is deferred with a stated blocker

SPEC-0005 delivers the C4 run surface through the CLI and defers the Python SDK
to its own specification. The blocker is concrete rather than a matter of
sequencing: pyo3 expands to unsafe code, the workspace sets
`unsafe_code = "forbid"`, and ADR-0003 permits unsafe only inside
optimizer-highs. An in-process binding therefore requires a decision record
amending ADR-0003, plus maturin packaging and a Python test layer in the gate.
AGENTS.md also states that Python under tools/ is validation tooling and not the
SDK. Reproduction: add a pyo3 dependency to any runtime crate and build. Next
step: decide the SDK's shape in its own specification, now backlog item C9; a
subprocess wrapper over the versioned run records needs no unsafe boundary and is
the cheaper option if an SDK is wanted before that decision.

## Resolved: the local extension registry is implemented

This was recorded from C4 through C5 and is now closed by C8 under
[SPEC-0009](../docs/specifications/SPEC-0009-extension-registry.md) and
[ADR-0008](../docs/decisions/ADR-0008-registry-resolution.md). `optimizer search`,
`optimizer verify` and `optimizer schedule solve` resolve a configuration's
extension policy through a registry document the caller names with `--registry`,
and registration, promotion, licenses, compatibility, authority basis and
inter-extension requirements are all checked rather than parked. The declaration
fields SPEC-0004 deliberately left unread — data needs, hardware and dependencies —
now have checked meanings.

Retained as the limits the implementation actually has, each recorded rather than
absorbed:

- A run record names each extension's identity and version but not the registry
  document that resolved it, so licenses and promotion state are auditable through
  the registry rather than through the record. Closing this needs a run-record v2
  and an ADR, because SPEC-0005 makes a change to the compared fields breaking.
- An extension is identified by identity and version, so two different builds of one
  version are indistinguishable. This is the same limitation already recorded for
  the pinned native library, and it is why the summary-difference diagnostic exists.
- The registry resolves only extensions this build provides. It cannot name a
  dynamically loaded native extension, and it refuses an entry requiring a GPU;
  both refusals are explicit and both remain recorded below.
- Provider construction happens before SPEC-0004's guarded host exists, so a
  provider that panics while constructing an extension is outside the
  panic-containment claim. The host's containment of `declare`, `propose` and
  `advise` is unchanged.
- Conformance establishes contract invariance only. A passing record means the
  contract held, never that the extension improved a search, which stays a C7
  question.

## Resolved: a scheduling run record with a producer registered now verifies

Recorded from C5 and closed by C8. `optimizer verify` previously re-executed every
record through the extension-free search entry point, so a record whose
configuration named an extension policy was refused as unsupported: re-running
without the named producer would have reproduced a search the record does not
describe, and its node counters would have differed for that reason alone.

Under [SPEC-0009](../docs/specifications/SPEC-0009-extension-registry.md)
requirement 19 the verifier reconstructs the producer a record names, through a
registry the caller passes with `--registry`. Reproduction of the closed case:
`optimizer schedule solve` with a configuration naming `flow-shop-neh` and a
registry, then `optimizer verify` on the resulting record with the same registry;
it agrees and exits 0. The gate re-executes such a record across a commit boundary
in `tools/verify_committed_record.py`. A record naming an extension policy with no
`--registry` is still refused, which is requirement 18 rather than a limitation.

## Resolved: a run record's identifier no longer depends on the clock

`optimizer search` built `record_id` as `run-{model_id}-{elapsed_ms}` and
`optimizer schedule solve` built `schedule-{model_id}-{elapsed_ms}`. The
identifier was a pure function of a measurement the project excludes from meaning
everywhere else: SPEC-0005 requirement 12 fixes elapsed time as diagnostic rather
than contractual, and verification ignores it. Two runs of the same search on the
same machine got different identifiers whenever the host spent a different number
of milliseconds, and two unrelated searches that took equally long collided.

Found by the C8 clean-checkout verification, which is the case it takes to see it:
the requirement 17 contract compares a record produced with a registry against one
produced without, and both runs completed in 0 ms on a warm working tree but in 0
and 1 ms on the clean clone.

Closed by SPEC-0005 requirement 1a, which now states that an identifier is derived
only from what the record describes. Both commands derive it from the SHA-256
digests of the input documents the record already carries, so a different model or
a different configuration yields a different identifier and a repeated run yields
the same one. Two runs of the same inputs sharing an identifier is the intended
reading rather than a residual collision: the identifier names the inputs, and
whether two such runs agree is what `optimizer verify` answers. Reproduction of the
closed case: run `optimizer search` twice over the same model and configuration and
compare the two `record_id` values; the contract test asserts this and was shown to
fail with the old derivation reinstated.

## Resolved: two SPEC-0009 acceptance gaps closed by diagnosis

Both were recorded when C8 was integrated and both are now closed, one by a
specification correction and one by a test that reaches a branch previously
believed possibly dead.

Requirement 14 said resolution "MUST NOT ... construct" a refused extension, which
was not true of the declaration- and role-mismatch paths: `Extension::declare` is
the authority being compared and the provider is what supplies the role, so both
are necessarily decided after construction. The rule is now split. Requirement 14
governs invocation, which holds everywhere. Requirement 14a governs construction
and names the three refusals that can be decided before it — an unprovided
identity, an unsatisfied data requirement and a gpu hardware requirement — and
states that a mismatch is constructed, read and then refused without ever being
invoked. This was a specification correction, not a code change; the
implementation was already right.

Requirement 20's record-versus-resolved version comparison is **reachable**, and
is now tested. The earlier doubt came from testing it the wrong way round:
restamping the *registry* is refused by the declaration check first, because the
extension still reports the version it always did. The rule the requirement
actually describes runs the other direction — a record naming a version the
current build no longer declares, which is what happens when a record outlives the
build that produced it. Restating the version in the record's extension summary
reaches it, and disabling the branch makes that test fail. The branch is not dead
and was not removed.

That diagnosis also found a defect in the acceptance gate itself.
`tools/verify_committed_record.py` restamped the registry and asserted only that
the restamped version appeared in stderr — but resolution's declaration-mismatch
message contains that version too, so the check passed on the wrong error and
never reached requirement 20. Its comment claimed an isolation it did not achieve.
The gate now covers both rules separately and each asserts the message its own
rule produces; with the requirement 20 branch disabled the gate step fails, where
before it passed. This is the same class of defect the C8 clean-checkout run
found: a check that passes for a reason other than the one it names.

## C8 requirements whose acceptance tests are thinner than the specification

SPEC-0009's acceptance section describes cases that the implementation does not
yet assert. These are recorded rather than quietly downgraded, because the
specification is accepted and its own test mapping is the thing out of date.

- Requirement 20's nondeterministic-record refusal has no test. Neither example
  extension declares nondeterminism, so producing such a record needs a fixture
  that does not exist in the CLI's provider table.
- Requirement 21's positive case — a run that agrees while reporting an extension
  summary difference as a diagnostic note — is asserted only in its negative form,
  that no difference is reported when none exists. `ExtensionDifference` has no
  unit test.
- Requirement 22's forfeited registry-backed record is not produced by any test.
  The forfeiture rule itself is covered without a registry under SPEC-0005.
- Requirement 18 is asserted for `optimizer schedule solve` but not for
  `optimizer search --registry` with a non-empty policy, because both extensions
  this build provides are flow-shop producers that cannot be constructed from a
  bare model. A search-command case needs a provider that takes no auxiliary
  instance.
- Requirement 1's document-level missing-field refusal and requirement 3's
  duplicate-field rejection are covered for entries but not for the document
  itself.

## Verification assumes an unchanged native library

`optimizer verify` re-runs a search and compares the two records field by field. A
divergence now reports whether the backend library, source revision or compiler
differs from the record's, so a changed engine is distinguishable from a wrong
result *in the diagnostic*. What remains unresolved is whether such a mismatch
should ever be **tolerated**: verification still fails, because deciding otherwise
would change the meaning of agreement and needs a new record version plus an ADR
under SPEC-0005's compatibility rule. Cross-host reproducibility is separately
untested, because floating-point behavior and library builds may differ between
machines, and closing it needs a second machine in CI rather than local code.
Agreement therefore remains evidence of determinism on one host over time, which
is what ADR-0006 claims and no more.

## Per-node work Track B measured and deliberately did not remove

Track B removed five items from the branch-and-bound node path without changing
any conclusion; see [active task](active-task.md) for the measurements. Two
candidates were identified, reasoned about and left in place, and both are
recorded here so they read as decisions rather than as oversights.

`node::relaxation` still clones the original model's constraints and objective
once per node — 5,175 nonzeros for the encoded ta001. `Model::rebound` removed the
revalidation that sat beside that copy but not the copy itself, and the copy is
now likely the dominant per-node cost. Reproduction: profile a node-budgeted
`schedule solve` over ta001 and attribute time inside `node::relaxation`. Next
step: sharing the rows between a model and its relaxations needs an `Rc` or `Arc`
inside `ModelDocument`, which is a public type in a crate other crates deserialize
through; that is a wide change and needs its own measurement before it is worth
making, not a follow-on commit.

Reusing the `Highs` object across nodes is permitted — SPEC-0003 requirement 23
forbids reusing a *basis*, not the instance — and is the obvious next per-node
item. It was deferred because the measurement harness that would justify it did
not exist when the ranking was made. Cross-node warm start and parallel search
remain forbidden by SPEC-0003 requirement 23 and SPEC-0002 requirement 5
respectively, and each needs its own decision record; neither is blocked on
measurement.

Also worth recording, because it is a gate property rather than an engine one:
until Track B's last commit both committed run records reported `nodes_explored:
1`, so `tools/verify_committed_record.py` had never re-executed a branching search
across a commit boundary. A multi-node fixture now closes that. Its
`nodes_pruned_infeasible` is 0 and is deliberately not asserted, because the
positional encoding's relaxation was feasible at every size tried and choosing a
fixture to hit that counter would be choosing it for the wrong reason.

## Checkpoint restart is still unimplemented

C2 defines and serializes `Checkpoint` and SPEC-0003 states that restart is not
implemented. The C4 run surface does not add a restart entry point either, so a
long search cannot be resumed and a run record cannot be continued. Verification
re-runs from the beginning under the record's own budgets. Reproduction: no CLI
command consumes a checkpoint. Next step: restart needs its own acceptance
evidence before any public entry point exists.

## The flow-shop encoding is correct but weak

Two limits recorded before implementation, both confirmed by it.

The positional encoding is exactly linear and its optimum equals the instance's
minimum makespan by construction, but its linear relaxation is weak and the model
is quadratic in the job count: a 20-job, 5-machine Taillard instance is 400 binary
variables. The executive is not expected to prove optimality at that size, so the
specification confines proven-optimal claims to tiny instances checked against
exhaustive permutation enumeration and confines the frozen subset to feasibility,
determinism and validated-incumbent evidence. This is a stated scope boundary, not
a defect, and it is why requirement 26 forbids recording a performance claim.
Reproduction: encode any 20-job instance and run the executive without a budget; a
node-limited run over `ta001` is asserted in the CLI contracts to report its limit
rather than an optimum. Next step: a stronger formulation or a scheduling-specific
bound would each need its own contract, and the evidence justifying one does not
exist yet.

Permutation schedules are also not optimal for the general flow shop beyond three
machines, confirmed by direct enumeration on a 3-job, 4-machine instance where the
best permutation schedule costs 50 and the best general schedule costs 47. The
permutation restriction is part of the problem C5 solves rather than an
approximation it makes, and nothing in the slice should be read as solving the
general flow shop.

## Dynamically loaded native extensions are not implemented

SPEC-0004 specifies host-contract-version negotiation and implements it in safe
Rust, but the versioned C-compatible boundary for separately distributed native
components is deliberately absent. It needs a second unsafe boundary, which
ADR-0003 prohibits outside optimizer-highs, so it requires an amending decision
record plus its own lifecycle, ABI-stability and crash-isolation evidence. This
is a recorded deferral, not a gap discovered late.

[SPEC-0009](../docs/specifications/SPEC-0009-extension-registry.md) does not change
this. Its registry *resolves* a named identity to an extension the build already
provides and refuses one it does not, so the registry is now the obvious place a
dynamically loaded extension would be named and deliberately cannot name one. That
makes the deferral more visible rather than closing it.
