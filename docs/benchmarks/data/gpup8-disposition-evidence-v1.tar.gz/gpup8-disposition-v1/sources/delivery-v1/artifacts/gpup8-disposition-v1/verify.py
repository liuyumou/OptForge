"""Read retained summaries and verify the disposition's historical boundary.

This is delivery verification, not a scientific rerun or certificate replay.
"""
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'artifacts/gpup8-disposition-v1'
REV = 'e0d9e8ad3ebea268299150b47df758002ce695a8'
ALLOWED = {'AGENTS.md', 'CHANGELOG.md', 'state/active-task.md',
           'state/backlog.yaml', 'state/known-failures.md', 'wiki/status.md',
           'docs/plans/gpu-lp-precision-roadmap.md'}


def load(name):
    return json.loads((ROOT / name).read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def ref(name):
    data = (ROOT / name).read_bytes()
    return dict(path=name, sha256=hashlib.sha256(data).hexdigest())


def blocks(text):
    found = re.findall(r'^  - id: (\S+)\n(.*?)(?=^  - id: |\Z)', text,
                       re.MULTILINE | re.DOTALL)
    assert len(found) == len(dict(found)), 'duplicate backlog task'
    return dict(found)


def field(block, key):
    return re.search(r'^    ' + re.escape(key) + r': (.*)$', block,
                     re.MULTILINE).group(1)


def main():
    old_backlog = git('show', REV + ':state/backlog.yaml').decode()
    new_backlog = (ROOT / 'state/backlog.yaml').read_text()
    old, new = blocks(old_backlog), blocks(new_backlog)
    edited_tasks = {'GPUP-8', 'GPUP-9', 'GPUP-8-DISPOSITION'}
    for key, value in old.items():
        if key not in edited_tasks:
            assert new[key] == value, ('historical task changed', key)
    assert field(new['GPUP-8'], 'acceptance') == field(old['GPUP-8'], 'acceptance')
    for key in ('GPUP-9', 'GPUP-8-DISPOSITION'):
        assert field(new[key], 'historical_acceptance') == field(old[key], 'acceptance')
    assert field(new['GPUP-8'], 'status') == 'closed_negative'
    assert field(new['GPUP-9'], 'status') == 'planned'
    assert field(new['GPUP-8-DISPOSITION'], 'status') == 'complete'
    assert field(new['GPUP-CERTIFIED-COST-GATE'], 'status') == 'planned'
    assert field(new['GPUP-PREP3'], 'status') == 'ready'
    assert 'next_ready_task: GPUP-PREP3\n' in new_backlog
    assert field(new['GPUP-9'], 'depends_on') == '[GPUP-7, GPUP-STATE, GPUP-ASSESS, GPUP-CERTIFIED-COST-GATE]'
    graph = {k: [v.strip() for v in field(b, 'depends_on').strip('[]').split(',') if v.strip()]
             for k, b in new.items()}
    visited, active = set(), set()

    def visit(key):
        assert key in graph, ('unknown dependency', key)
        assert key not in active, ('dependency cycle', key)
        if key in visited:
            return
        active.add(key)
        for predecessor in graph[key]:
            visit(predecessor)
        active.remove(key)
        visited.add(key)

    for key in graph:
        visit(key)
    # Verify bytes, not just index status. Stream large historical evidence parts.
    retained = []
    for item in git('ls-tree', '-r', '-z', REV).split(b'\0'):
        if not item:
            continue
        metadata, name = item.split(b'\t', 1)
        mode, kind, oid = metadata.decode().split()
        name = name.decode()
        assert kind == 'blob'
        if name in ALLOWED:
            if name != 'state/backlog.yaml':
                before = git('show', REV + ':' + name)
                after = (ROOT / name).read_bytes()
                header, remainder = before.split(b'\n', 1)
                assert after.startswith(header + b'\n') and remainder in after, name
            continue
        path = ROOT / name
        assert mode in ('100644', '100755'), ('unhandled mode', name, mode)
        digest = hashlib.sha1(b'blob ' + str(path.stat().st_size).encode() + b'\0')
        with path.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1 << 20), b''):
                digest.update(chunk)
        assert digest.hexdigest() == oid, ('historical bytes changed', name)
        retained.append(dict(path=name, git_blob=oid))

    evidence = [
        'docs/benchmarks/data/tensor-expanded/recovery-result-v1.json',
        'docs/benchmarks/data/tensor-expanded/recovery-final-accounting-v1.json',
        'docs/benchmarks/data/mixed2-confirm2-analysis-v1.json',
        'docs/benchmarks/data/mixed2-confirm2-acceptance-v1.json',
        'docs/benchmarks/data/checker2-analysis-v1.json',
        'docs/benchmarks/data/checker2-diagnosis-v1.json',
        'docs/benchmarks/data/checker2-acceptance-v1.json',
        'docs/benchmarks/data/external-baseline-native-result-v1.json',
    ]
    gpup = load(evidence[0])
    assert gpup['status'] == 'incomplete' and not gpup['working_families']
    assert gpup['timings_executed'] == gpup['certified_timings'] == 0
    assert gpup['completed_profiles'] == 6 and gpup['unexecuted_profiles'] == 9
    assert not gpup['certified_latency_gain'] and gpup['ledger_events'] == 17438
    mixed = load(evidence[2])
    assert mixed['status'] == 'complete-confirmation'
    assert mixed['sessions'] == 512 and mixed['solves'] == 16384
    mixed_passes = sum(row['useful_scoped_gain'] for row in mixed['rows'])
    mixed_110 = sum(row['provisional_110_lower_pass'] for row in mixed['rows'])
    assert mixed_passes == 5 and mixed_110 == 0
    checker = load(evidence[4])
    assert checker['complete_sessions'] == 512 and checker['complete_solves'] == 16384
    assert checker['scoped_passes'] == 16 and checker['provisional_passes'] == 13
    ratios = [row['speedup']['median'] for row in checker['comparisons']]
    strict = next(row for row in checker['comparisons'] if
                  row['family'] == 'dense-coupled-2048' and
                  row['tier'] == 'certified-1e-9' and row['lane'] == 'fp4x2')
    totals = strict['partitions']['candidate']['totals_ns']
    shares = {k: totals[k] / totals['complete_session_ns'] for k in ('setup_ns', 'checker')}
    assert round(100 * shares['setup_ns'], 1) == 40.5
    assert round(100 * shares['checker'], 1) == 34.8
    # The prospective exact-binomial intervals and balanced factorial order.
    noncoverage = {rank: 2 * sum(math.comb(16, i) for i in range(rank)) / 2**16
                   for rank in (2, 3)}
    assert noncoverage[2] * 64 <= .05 and noncoverage[3] * 8 <= .05
    orders = ['ABCD', 'BDAC', 'CADB', 'DCBA'] * 4
    for a in 'ABCD':
        assert all(sum(order.index(a) == pos for order in orders) == 4 for pos in range(4))
        for b in 'ABCD':
            if a != b:
                assert sum(order.index(a) < order.index(b) for order in orders) == 8
    result = dict(status='passed', baseline=REV, historical_files_exact=len(retained),
                  historical_files=retained, prior_handoff_text_exact=True,
                  unchanged_backlog_tasks=len(old) - len(edited_tasks),
                  historical_acceptance_preserved=True, dependency_graph_acyclic=True,
                  evidence=[ref(name) for name in evidence],
                  gpup8=dict(scientific_status=gpup['status'], administrative_status='closed_negative',
                             working_families=False, certified_latency_gain=False, timings_executed=0),
                  mixed2=dict(sessions=512, solves=16384, scoped_passes=mixed_passes,
                              provisional_passes=mixed_110),
                  checker2=dict(sessions=512, solves=16384, scoped_passes=16,
                                provisional_passes=13, within_lane_ratio_range=[min(ratios), max(ratios)],
                                strict_coupled2048_fp4_aggregate_cost_shares=shares),
                  prep3=dict(cpu_ceiling=24000, gpu_ceiling=0, allocation_opened=False,
                             factorial_processes=512, candidate_processes=128,
                             exact_median_noncoverage=noncoverage, balanced_order=True),
                  gpup9_released=False, public_defaults_changed=False,
                  numerical_sources_changed=False, scientific_cells_executed=0,
                  verification_scope='retained summaries, planning and historical bytes; no numerical replay')
    (BASE / 'verification.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('historical_files', 'evidence')}, indent=2))


if __name__ == '__main__':
    main()
