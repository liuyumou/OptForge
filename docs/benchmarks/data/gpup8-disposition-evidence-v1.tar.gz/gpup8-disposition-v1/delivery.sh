#!/usr/bin/env bash
set -euo pipefail
python artifacts/gpup8-disposition-v1/verify.py
python tools/build_docs.py
git diff --check
