"""Verify evidence-informed milestone recognition without rerunning science."""
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'artifacts/gpup8-redesign-v1'
REV = '3b64b08ed21f39b8ef49f3429c991ca610e1bdb9'
ALLOWED = {'AGENTS.md', 'CHANGELOG.md', 'state/active-task.md', 'state/backlog.yaml',
           'state/known-failures.md', 'wiki/status.md',
           'docs/plans/gpu-lp-precision-roadmap.md', 'docs/plans/lp-prep3.md'}


def load(name):
    return json.loads((ROOT / name).read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def ref(name):
    return dict(path=name, sha256=hashlib.sha256((ROOT / name).read_bytes()).hexdigest())


def blocks(text):
    found = re.findall(r'^  - id: (\S+)\n(.*?)(?=^  - id: |^research_phases:|\Z)',
                       text, re.MULTILINE | re.DOTALL)
    assert len(found) == len(dict(found))
    return dict(found)


def field(block, key):
    return re.search(r'^    ' + re.escape(key) + r': (.*)$', block,
                     re.MULTILINE).group(1)


def main():
    old_text = git('show', REV + ':state/backlog.yaml').decode()
    new_text = (ROOT / 'state/backlog.yaml').read_text()
    old, new = blocks(old_text), blocks(new_text)
    changed = {'GPUP-PREP3', 'GPUP-CERTIFIED-COST-GATE', 'GPUP-8', 'GPUP-9'}
    for key, value in old.items():
        if key not in changed:
            assert new[key] == value, ('unrelated task changed', key)
    assert field(new['GPUP-8-LEGACY'], 'acceptance') == field(old['GPUP-8'], 'acceptance')
    assert field(new['GPUP-8-LEGACY'], 'status') == 'retired_incomplete'
    assert field(new['GPUP-8'], 'status') == 'complete'
    assert field(new['GPUP-9'], 'status') == 'ready'
    assert field(new['GPUP-CERTIFIED-COST-GATE'], 'status') == 'superseded'
    assert field(new['GPUP-CERTIFIED-COST-GATE'], 'historical_acceptance') == field(old['GPUP-CERTIFIED-COST-GATE'], 'acceptance')
    assert field(new['GPUP-9'], 'historical_acceptance_adr0076') == field(old['GPUP-9'], 'acceptance')
    assert field(new['GPUP-9'], 'historical_acceptance') == field(old['GPUP-9'], 'historical_acceptance')
    assert 'next_ready_task: GPUP-9\n' in new_text
    graph = {k: [s.strip() for s in field(v, 'depends_on').strip('[]').split(',') if s.strip()]
             for k, v in new.items()}
    assert graph['GPUP-9'] == ['GPUP-7', 'GPUP-STATE', 'GPUP-ASSESS', 'GPUP-8']
    assert all(field(new[k], 'status') == 'complete' for k in graph['GPUP-9'])
    visited, active = set(), set()

    def visit(key):
        assert key in graph and key not in active
        if key in visited:
            return
        active.add(key)
        for dependency in graph[key]:
            visit(dependency)
        active.remove(key)
        visited.add(key)

    for key in graph:
        visit(key)
    # Verify every old byte except explicitly changed current-planning files.
    retained = []
    for item in git('ls-tree', '-r', '-z', REV).split(b'\0'):
        if not item:
            continue
        meta, name = item.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        name = name.decode()
        assert kind == 'blob' and mode in ('100644', '100755')
        if name in ALLOWED:
            if name != 'state/backlog.yaml':
                before = git('show', REV + ':' + name)
                after = (ROOT / name).read_bytes()
                header, rest = before.split(b'\n', 1)
                assert after.startswith(header + b'\n') and rest in after, name
            continue
        path = ROOT / name
        digest = hashlib.sha1(b'blob ' + str(path.stat().st_size).encode() + b'\0')
        with path.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1 << 20), b''):
                digest.update(chunk)
        assert digest.hexdigest() == oid, ('historical bytes changed', name)
        retained.append(dict(path=name, git_blob=oid))
    manifest_data = (json.dumps(retained, sort_keys=True, indent=2) + '\n').encode()
    (BASE / 'historical-files.json').write_bytes(manifest_data)

    names = [
        'docs/benchmarks/data/mixed2-confirm2-analysis-v1.json',
        'docs/benchmarks/data/mixed2-confirm2-acceptance-v1.json',
        'docs/benchmarks/data/checker2-analysis-v1.json',
        'docs/benchmarks/data/checker2-acceptance-v1.json',
        'docs/benchmarks/data/tensor-expanded/recovery-result-v1.json',
        'docs/benchmarks/data/mixed2-confirm2-accounting-v1.json',
        'docs/benchmarks/data/checker2-accounting-v1.json',
        'docs/benchmarks/data/gpup8-disposition-acceptance-v1.json',
        'docs/decisions/ADR-0042-hybrid-tensor-components.md',
        'docs/decisions/ADR-0076-gpup8-disposition.md',
        'docs/specifications/SPEC-0041-mixed2-confirm2.md',
    ]
    mixed = load(names[0])
    admission = load(names[1])
    assert mixed['status'] == admission['scientific_confirmation'] == 'complete-confirmation'
    assert admission['status'] == 'passed' and admission['cleanup_empty']
    assert admission['portable_replay'] and admission['supervisor_contracts'] == 39
    assert (admission['serial_responses'], admission['serial_requests'], admission['serial_unique']) == (17984, 58448, 144)
    assert mixed['sessions'] == mixed['planned_sessions'] == 512
    assert mixed['solves'] == mixed['certificates'] == 16384
    assert not mixed['failed_blocks'] and not mixed['missing_cells']
    assert not mixed['production_adoption'] and not admission['production_adoption']
    rows = []
    for row in mixed['rows']:
        assert row['blocks'] == list(range(32))
        for key in ('speedup', 'saved_ms'):
            stats = row[key]
            values = sorted(stats['values'])
            assert stats['n'] == len(values) == 32 and stats['rank'] == 8
            assert stats['lower'] == values[7] and stats['upper'] == values[24]
            assert math.isclose(stats['median'], statistics.median(values), rel_tol=1e-14)
            coverage = 1 - 2 * sum(math.comb(32, i) for i in range(8)) / 2**32
            assert stats['coverage'] == coverage and 16 * (1 - coverage) <= .05
        passed = row['speedup']['lower'] > 1 and row['saved_ms']['lower'] > 10
        provisional = row['speedup']['lower'] > 1.10
        assert passed == row['useful_scoped_gain']
        assert provisional == row['provisional_110_lower_pass']
        rows.append(dict(family=row['family'], tier=row['tier'], scoped_pass=passed,
                         provisional_110_pass=provisional,
                         speedup={k:row['speedup'][k] for k in ('median','lower','upper')},
                         saved_ms={k:row['saved_ms'][k] for k in ('median','lower','upper')}))
    assert len(rows) == 8 and sum(r['scoped_pass'] for r in rows) == 5
    strict = [r for r in rows if r['tier'] == 'certified-1e-9' and r['scoped_pass']]
    assert {r['family'] for r in strict} == {'dense-coupled-1024','dense-coupled-2048','dense-generic-1024'}
    assert not any(r['provisional_110_pass'] for r in rows)
    checker = load(names[2])
    assert checker['scoped_passes'] == 16 and checker['provisional_passes'] == 13
    assert load(names[3])['status'] == 'passed'
    legacy = load(names[4])
    assert legacy['status'] == 'incomplete' and legacy['timings_executed'] == 0
    assert not legacy['working_families'] and not legacy['certified_latency_gain']
    result = dict(status='passed', baseline=REV, historical_files_exact=len(retained),
                  historical_manifest=ref('artifacts/gpup8-redesign-v1/historical-files.json'),
                  prior_handoff_text_exact=True, unrelated_backlog_tasks_exact=len(old)-len(changed),
                  original_acceptance_strings_retained=True, dependency_graph_acyclic=True,
                  evidence=[ref(name) for name in names], original_comparisons=rows,
                  gpup8=dict(status='complete', scope='retained FP4 complete prepared-session research capability',
                             evidence_informed_recognition=True, new_prospective_confirmation=False,
                             full_sessions=512, certified_solves=16384, scoped_passes=5, strict_passes=3,
                             retained_binary=admission['binary'], retained_image=admission['image'],
                             retained_serial_responses=17984, retained_serial_assessments=58448,
                             retained_portable_replay=True),
                  legacy=dict(status='retired_incomplete', scientific_status='incomplete', original_gate_passed=False),
                  prior_replacement_gate='superseded; not passed',
                  gpup9=dict(status='ready', next_action='define frozen protocol and independent budget',
                             scientific_execution_released=False, allocation_opened=False),
                  prep3_required_for_gpup9=False, hosted_ci_required_for_research=False,
                  public_defaults_changed=False, public_adoption=False,
                  numerical_sources_changed=False, scientific_cells_executed=0,
                  verification_scope='historical bytes and original retained statistical decisions; no certificate replay')
    (BASE / 'verification.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('evidence','original_comparisons')}, indent=2))


if __name__ == '__main__':
    main()
