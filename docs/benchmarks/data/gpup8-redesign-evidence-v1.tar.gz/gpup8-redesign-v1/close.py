"""Settle closing administration and package the completed redesign evidence."""
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'artifacts/gpup8-redesign-v1'
DATA = ROOT / 'docs/benchmarks/data'
NS = 10**9


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def ref(path):
    return dict(path=str(path.relative_to(ROOT)),
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def main():
    assert not (BASE / 'CLOSED.json').exists()
    journal = read(BASE / 'cpu-journal.json')
    assert not journal['active'] and not journal['failed']
    reports = [read(BASE / (name + '.json')) for name in
               ('native-v1', 'verification-v1', 'delivery-v1')]
    for report in reports:
        assert report['status'] == 'passed'
        assert report['guardian_cleanup']['empty'] and report['result']['cleanup']['empty']
    manifest = read(BASE / 'sources/delivery-v1/manifest.json')
    for source in manifest['sources']:
        assert ref(ROOT / source['path']) == source
    assert journal['stages']['margin']['charged_cpu_ns'] == 0
    journal['stages']['margin']['charged_cpu_ns'] = 128 * NS
    total = sum(stage['charged_cpu_ns'] for stage in journal['stages'].values())
    assert total <= journal['ceiling_cpu_ns'] == 8000 * NS
    assert all(stage['charged_cpu_ns'] <= stage['cap_cpu_ns'] for stage in journal['stages'].values())
    closure = dict(status='closed', cpu_ns=total, cpu_ceiling_ns=8000 * NS,
                   gpu_ns=0, preparation_admin_cpu_ns=512 * NS,
                   closing_admin_cpu_ns=128 * NS, failed_reservations=0,
                   cleanup_empty=True, historical_transfer=0,
                   next_experiment_allocation_opened=False,
                   method='four times supervised wall plus reserved finalization; separate fixed preparation/closing admin')
    write(BASE / 'cpu-journal.json', journal)
    write(BASE / 'CLOSED.json', closure)
    # Closing writes cannot be part of their own digest; archive only settled
    # operational records and sources, then bind the archive from acceptance.
    archive = DATA / 'gpup8-redesign-evidence-v1.tar.gz'
    paths = sorted(p for p in BASE.rglob('*') if p.is_file() and p.suffix not in ('.lock', '.pending'))
    with tarfile.open(archive, 'w:gz') as tar:
        for path in paths:
            tar.add(path, arcname=str(path.relative_to(ROOT / 'artifacts')), recursive=False)
    with tarfile.open(archive, 'r:gz') as tar:
        members = tar.getmembers()
        assert len(members) == len(paths) and len({m.name for m in members}) == len(paths)
        for member, path in zip(members, paths):
            assert member.isfile()
            assert tar.extractfile(member).read() == path.read_bytes()
    verification = read(BASE / 'verification.json')
    write(DATA / 'gpup8-redesign-verification-v1.json', verification)
    acceptance = dict(status='passed', baseline=manifest['baseline'],
                      rust_tests=638, workspace_rust_tests=637, buffered_transport_rust_tests=1,
                      python_tests=785, docs_pages=278,
                      checks=['full native tools/check.sh', 'exact historical bytes',
                              'retained summary mapping', 'dependency graph',
                              'all original FP4 comparison decisions and exact interval arithmetic',
                              'final documentation and diff hygiene', 'archive byte verification'],
                      historical_files_exact=verification['historical_files_exact'],
                      unrelated_backlog_tasks_exact=verification['unrelated_backlog_tasks_exact'],
                      prior_handoff_text_exact=True, numerical_replay_performed=False,
                      scientific_cells_executed=0, gpup9_research_ready=True,
                      gpup9_scientific_execution_released=False,
                      gpup8_scope='retained FP4 complete prepared-session research capability',
                      legacy_status='retired_incomplete',
                      public_defaults_changed=False, hosted_ci_resolved=False,
                      hosted_ci_status='prior observation: startup_failure; zero jobs; not requeried here',
                      accounting=closure, stages=journal['stages'],
                      resource_receipts=[ref(BASE / (name + '.json')) for name in
                                         ('native-v1', 'verification-v1', 'delivery-v1')],
                      source_manifest=ref(BASE / 'sources/delivery-v1/manifest.json'),
                      prior_hosted_observation=ref(DATA / 'gpup8-disposition-acceptance-v1.json'),
                      verification=ref(DATA / 'gpup8-redesign-verification-v1.json'),
                      evidence=ref(archive), archive_files=len(paths),
                      max_sample_gap_ns=max(r['result']['max_sample_gap_ns'] for r in reports),
                      max_sample_work_ns=max(r['result']['max_sample_work_ns'] for r in reports),
                      peak_sampled_rss_bytes=max(r['result']['peak_rss_bytes'] for r in reports),
                      advisory_exceedances=sum(len(r['result']['timing_exceedances']) for r in reports),
                      hard_memory_enclosure=False, cleanup_empty=True)
    write(DATA / 'gpup8-redesign-acceptance-v1.json', acceptance)
    print(json.dumps(dict(cpu_seconds=total/NS, gpu_seconds=0, archive_files=len(paths),
                          archive_bytes=archive.stat().st_size, status='closed')))


if __name__ == '__main__':
    main()
